import Link from "next/link";
import { ChevronDown } from "lucide-react";
import { dictionaries } from "@/lib/i18n";
import { levels } from "@/lib/learner";
import { feedbackModes, speechRates, voiceChoices } from "@/lib/practice";
import { practiceCopy } from "@/lib/practice-i18n";
import { availableVoices } from "@/lib/practice-provider";
import { researchCopy } from "@/lib/research-i18n";
import { getViewer } from "@/lib/preferences";
import { savePreferences } from "../actions";

type PageProps = {
  searchParams: Promise<{ error?: string }>;
};

export default async function SettingsPage({ searchParams }: PageProps) {
  const { preferences: { locale, level }, user, needsSetup, practice } = await getViewer();
  const t = dictionaries[locale];

  const title = needsSetup ? t.setupTitle : t.settings;
  const { error } = await searchParams;
  const p = practiceCopy[locale];
  const voices = availableVoices();
  const voiceOptions = voiceChoices.filter((voice) => voice === "default" || voices[voice]);

  return (
    <section className="subpage">
      {!needsSetup && <Link className="back" href="/">{t.back}</Link>}
      <h1>{title}</h1>
      <form className="panel preferences" action={savePreferences}>
        <label htmlFor="locale">{t.language}</label>
        <div className="select-wrap">
          <select id="locale" name="locale" defaultValue={locale}>
            <option value="en" lang="en">English</option>
            <option value="zh" lang="zh-Hans">中文</option>
          </select>
          <ChevronDown size={17} aria-hidden="true" />
        </div>
        <label htmlFor="level">{t.level}</label>
        <div className="select-wrap">
          <select id="level" name="level" defaultValue={level}>
            {levels.map((item) => <option key={item} value={item}>HSK {item}</option>)}
          </select>
          <ChevronDown size={17} aria-hidden="true" />
        </div>
        {practice && (
          <>
            <label htmlFor="default-mode">{p.defaultMode}</label>
            <div className="select-wrap">
              <select id="default-mode" name="feedback-mode" defaultValue={practice.defaultMode}>
                {feedbackModes.map((mode) => <option key={mode} value={mode}>{p.modes[mode]}</option>)}
              </select>
              <ChevronDown size={17} aria-hidden="true" />
            </div>
            <label htmlFor="speech-rate">{p.speechRate}</label>
            <div className="select-wrap">
              <select id="speech-rate" name="speech-rate" defaultValue={practice.rate ?? "auto"}>
                {speechRates.map((rate) => <option key={rate} value={rate}>{rate === "auto" ? p.autoRate : `${rate}×`}</option>)}
              </select>
              <ChevronDown size={17} aria-hidden="true" />
            </div>
            {voiceOptions.length > 1 && (
              <>
                <label htmlFor="voice">{p.voice}</label>
                <div className="select-wrap">
                  <select id="voice" name="voice" defaultValue={voiceOptions.find((voice) => voice === practice.voice) ?? "default"}>
                    {voiceOptions.map((voice) => <option key={voice} value={voice}>{p.voices[voice]}</option>)}
                  </select>
                  <ChevronDown size={17} aria-hidden="true" />
                </div>
              </>
            )}
          </>
        )}
        <p>{user ? t.syncedPreferences : t.preferences}</p>
        {error === "invalid" && <p className="form-error" role="alert">{t.invalidPreferences}</p>}
        {error === "save" && <p className="form-error" role="alert">{t.saveError}</p>}
        <button className="button" type="submit">{t.save}</button>
      </form>
      {practice && <Link className="lesson-secondary learning-heading" href="/research">{researchCopy[locale].consent}</Link>}
    </section>
  );
}
