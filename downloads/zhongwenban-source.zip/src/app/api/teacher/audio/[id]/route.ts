import { isSessionId } from "@/lib/practice";
import { readOriginal } from "@/lib/research-storage";
import { privateDownloadHeaders } from "@/lib/research-export";
import { teacherAccess, teacherRecordings } from "@/lib/teacher";

export const runtime = "nodejs";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const access = await teacherAccess();
    if (access.status !== 200) return new Response(null, { status: access.status, headers: privateDownloadHeaders });
    const { id } = await params;
    if (!isSessionId(id)) return new Response(null, { status: 404, headers: privateDownloadHeaders });
    const [recording] = await teacherRecordings(access.database, access.teacherId, {}, id);
    if (!recording) return new Response(null, { status: 404, headers: privateDownloadHeaders });

    const range = request.headers.get("range") ?? undefined;
    if (range && !/^bytes=(\d{1,10}-\d{0,10}|-\d{1,10})$/.test(range)) {
      return new Response(null, { status: 416, headers: privateDownloadHeaders });
    }
    const object = await readOriginal(recording.object_key, range);
    if (!object.Body) return new Response(null, { status: 502, headers: privateDownloadHeaders });
    const headers = new Headers({
      ...privateDownloadHeaders, "Content-Type": recording.mime_type, "Accept-Ranges": "bytes",
    });
    if (object.ContentRange) headers.set("Content-Range", object.ContentRange);
    if (object.ContentLength !== undefined) headers.set("Content-Length", String(object.ContentLength));
    return new Response(object.Body.transformToWebStream(), { status: object.ContentRange ? 206 : 200, headers });
  } catch (error) {
    const status = typeof error === "object" && error !== null && "name" in error && error.name === "InvalidRange" ? 416 : 502;
    return new Response(null, { status, headers: privateDownloadHeaders });
  }
}
