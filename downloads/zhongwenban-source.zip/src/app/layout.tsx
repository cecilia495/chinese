import type { Metadata } from "next";
import Link from "next/link";
import { BookOpen, ChartNoAxesColumnIncreasing, ChevronDown, Globe2, Settings, UserRound } from "lucide-react";
import { dictionaries } from "@/lib/i18n";
import { getViewer } from "@/lib/preferences";
import "./globals.css";

export const metadata: Metadata = {
  title: "中文伴 · Speak Chinese with AI",
  description: "Build confidence in Mandarin through everyday conversations.",
};

export default async function Layout({ children }: Readonly<{ children: React.ReactNode }>) {
  const { preferences: { locale, level }, user, accountsEnabled, needsSetup } = await getViewer();
  const t = dictionaries[locale];

  return (
    <html lang={locale === "zh" ? "zh-Hans" : "en"}>
      <body>
        <a className="skip-link" href="#main">{t.skip}</a>
        <header className="site-header">
          <div className="header-inner">
            <Link className="brand" href="/" aria-label={t.home}>
              <span className="seal" lang="zh-Hans" aria-hidden="true">伴</span>
              <span className="brand-text"><strong lang="zh-Hans">中文伴</strong><span>{t.footer}</span></span>
            </Link>
            <nav className="header-controls" aria-label={t.settings}>
              <Link className="pill" href="/settings#level" aria-label={`${t.level}: HSK ${level}`}>
                HSK {level}<ChevronDown size={14} aria-hidden="true" />
              </Link>
              <Link className="language-link" href="/settings#locale" aria-label={t.language}>
                <Globe2 size={18} aria-hidden="true" /><span>{locale === "en" ? "English" : "中文"}</span>
              </Link>
              <Link className="icon-link" href="/settings" aria-label={t.settings} title={t.settings}>
                <Settings size={20} aria-hidden="true" />
              </Link>
            </nav>
          </div>
        </header>
        <main id="main" className="main">{children}</main>
        <footer className="site-footer">
          <nav aria-label={t.personal}>
            <Link href="/vocabulary"><BookOpen size={18} aria-hidden="true" />{t.vocabulary}</Link>
            <Link href="/progress"><ChartNoAxesColumnIncreasing size={18} aria-hidden="true" />{t.progress}</Link>
          </nav>
          {accountsEnabled && !needsSetup && <Link href="/account"><UserRound size={18} aria-hidden="true" />{user ? t.account.title : t.account.signIn}</Link>}
        </footer>
      </body>
    </html>
  );
}
