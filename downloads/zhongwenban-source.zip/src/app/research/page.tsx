import Link from "next/link";
import { redirect } from "next/navigation";
import { getDatabase } from "@/lib/db";
import { dictionaries } from "@/lib/i18n";
import { getViewer } from "@/lib/preferences";
import { consentVersion, researchStatus } from "@/lib/research";
import { researchCopy } from "@/lib/research-i18n";
import { researchStorageConfigured } from "@/lib/research-storage";
import { Consent } from "./consent";

export default async function ResearchPage() {
  const { user, needsSetup, preferences: { locale } } = await getViewer();
  if (needsSetup) redirect("/settings");
  const database = getDatabase();
  const status = user && database ? await researchStatus(database, user.id) : undefined;
  const t = researchCopy[locale];

  return <section className="subpage">
    <Link className="back" href="/">{dictionaries[locale].back}</Link>
    <h1>{t.title}</h1>
    {status ? <Consent locale={locale} {...status} configured={researchStorageConfigured()} version={consentVersion} />
      : <div className="panel"><Link href="/account" className="button">{t.needAccount}</Link></div>}
  </section>;
}
