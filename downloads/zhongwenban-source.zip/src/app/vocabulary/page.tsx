import Link from "next/link";
import { redirect } from "next/navigation";
import { getDatabase } from "@/lib/db";
import { dictionaries } from "@/lib/i18n";
import { learningCopy } from "@/lib/learning-i18n";
import { savedVocabulary } from "@/lib/learning-store";
import { getViewer } from "@/lib/preferences";
import { Library } from "./library";

export default async function VocabularyPage() {
  const { user, accountsEnabled, needsSetup, preferences: { locale } } = await getViewer();
  if (needsSetup) redirect("/settings");
  const t = dictionaries[locale];
  const learning = learningCopy[locale];
  const database = getDatabase();

  return (
    <section className="subpage lesson">
      <Link className="back" href="/">{t.back}</Link>
      <h1>{t.vocabulary}</h1>
      {user && database ? <Library initial={await savedVocabulary(database, user.id)} locale={locale} />
        : <div className="panel">{accountsEnabled ? <Link href="/account" className="button">{learning.signIn}</Link>
          : <p>{learning.unavailable}</p>}</div>}
    </section>
  );
}
