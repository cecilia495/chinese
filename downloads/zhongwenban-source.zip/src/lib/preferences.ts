import { cache } from "react";
import { cookies, headers } from "next/headers";
import { getAuth } from "./auth";
import { getDatabase } from "./db";
import type { FeedbackMode, SpeechRate, VoiceChoice } from "./practice";
import { isLevel, isLocale, type LearnerPreferences } from "./learner";

type PracticePreferences = { defaultMode: FeedbackMode; rate: SpeechRate | null; voice: VoiceChoice | null };

export const getViewer = cache(async () => {
  const jar = await cookies();
  const locale = jar.get("zhb_locale")?.value;
  const level = jar.get("zhb_hsk")?.value;
  const guest: LearnerPreferences = {
    locale: isLocale(locale) ? locale : "en",
    level: isLevel(level) ? level : "2",
  };

  const auth = getAuth();
  const database = getDatabase();
  const session = auth && database ? await auth.api.getSession({ headers: await headers() }) : null;
  if (!session || !database) {
    return { preferences: guest, user: null, needsSetup: false, accountsEnabled: Boolean(auth), practice: null };
  }

  const { rows } = await database.query<LearnerPreferences & PracticePreferences>(
    `SELECT interface_language AS locale, hsk_level AS level, default_feedback_mode AS "defaultMode",
            speech_rate::text AS rate, voice_id AS voice FROM learner_profiles WHERE user_id = $1`,
    [session.user.id],
  );
  return {
    preferences: rows[0] ?? guest,
    practice: rows[0] ?? null,
    user: session.user,
    needsSetup: rows.length === 0,
    accountsEnabled: true,
  };
});
