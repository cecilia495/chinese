import Link from "next/link";
import { redirect } from "next/navigation";
import { getDatabase } from "@/lib/db";
import { getDiningLesson } from "@/lib/dining";
import { dictionaries } from "@/lib/i18n";
import { learningCopy } from "@/lib/learning-i18n";
import { getLearningProgress } from "@/lib/learning-store";
import { getViewer } from "@/lib/preferences";

export default async function ProgressPage() {
  const { user, accountsEnabled, needsSetup, preferences: { locale } } = await getViewer();
  if (needsSetup) redirect("/settings");
  const t = dictionaries[locale];
  const learning = learningCopy[locale];
  const database = getDatabase();
  const progress = user && database ? await getLearningProgress(database, user.id) : undefined;
  const minutes = new Intl.NumberFormat(locale, { style: "unit", unit: "minute", unitDisplay: "short" });
  const seconds = new Intl.NumberFormat(locale, { style: "unit", unit: "second", unitDisplay: "short" });
  const duration = progress && [
    progress.seconds >= 60 ? minutes.format(Math.floor(progress.seconds / 60)) : "",
    seconds.format(progress.seconds % 60),
  ].filter(Boolean).join(" ");
  const stats = progress && [
    [learning.runs, progress.lessonRuns],
    [learning.tasks, progress.tasks],
    [learning.sessions, progress.sessions],
    [learning.spoken, progress.spoken],
    [learning.time, duration],
    [learning.words, progress.words],
    [learning.due, progress.due],
  ];

  return (
    <section className="subpage lesson">
      <Link className="back" href="/">{t.back}</Link>
      <h1>{t.progress}</h1>
      {progress && stats ? (
        <div className="panel">
          <h2>{learning.topics}</h2>
          {progress.levels.length
            ? <ul>{progress.levels.map((level) => <li key={level}>HSK {level} · {getDiningLesson(level)?.title[locale]}</li>)}</ul>
            : <p>{learning.noHistory}</p>}
          <dl className="progress-list">
            {stats.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}
          </dl>
          <h2>{learning.recent}</h2>
          <p>{progress.feedback ?? learning.noFeedback}</p>
        </div>
      ) : <div className="panel">{accountsEnabled ? <Link href="/account" className="button">{learning.signIn}</Link>
        : <p>{learning.unavailable}</p>}</div>}
    </section>
  );
}
