import { authorizePractice, practiceFailure as fail, readPracticeJson } from "@/lib/practice-request";
import { consentVersion, grantRecordingConsent, researchStatus, withdrawRecordingConsent } from "@/lib/research";
import { researchStorageConfigured } from "@/lib/research-storage";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const access = await authorizePractice(request);
    if (access.error) return access.error;
    const input = await readPracticeJson(request);
    const { database, user } = access;
    if (input?.action === "grant" && input.version === consentVersion) {
      if (!researchStorageConfigured()) return fail(503);
      await grantRecordingConsent(database, user.id);
      return Response.json(await researchStatus(database, user.id));
    }
    if (input?.action === "withdraw") {
      const deletion = await withdrawRecordingConsent(database, user.id);
      return Response.json({ ...await researchStatus(database, user.id), ...deletion });
    }
    return fail(400);
  } catch {
    return fail(503);
  }
}
