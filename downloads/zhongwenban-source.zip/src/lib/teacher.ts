import { headers } from "next/headers";
import type { Pool } from "pg";
import { getAuth } from "./auth";
import { getDatabase } from "./db";
import { isLevel } from "./learner";
import { isKind, isSessionId } from "./practice";

export async function teacherAccess() {
  const auth = getAuth();
  const database = getDatabase();
  if (!auth || !database) return { status: 503 } as const;
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session) return { status: 401 } as const;
  const authorized = await database.query("SELECT 1 FROM teacher_roles WHERE user_id = $1", [session.user.id]);
  if (!authorized.rowCount) return { status: 403 } as const;
  return { status: 200, database, teacherId: session.user.id } as const;
}

export type TeacherFilters = { student?: string; session?: string; level?: string; kind?: string; from?: string; to?: string };

function validDate(value?: string) {
  if (!value || value.startsWith("0000") || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return undefined;
  const date = new Date(value + "T00:00:00Z");
  return Number.isNaN(date.valueOf()) || date.toISOString().slice(0, 10) !== value ? undefined : value;
}

export function teacherFilters(input: Record<string, string | string[] | undefined>): TeacherFilters {
  return {
    student: isSessionId(input.student) ? input.student : undefined,
    session: isSessionId(input.session) ? input.session : undefined,
    kind: isKind(input.kind) ? input.kind : undefined,
    level: isLevel(input.level) ? input.level : undefined,
    from: validDate(typeof input.from === "string" ? input.from : undefined),
    to: validDate(typeof input.to === "string" ? input.to : undefined),
  };
}

export function invalidTeacherFilters(input: Record<string, string | string[] | undefined>, filters: TeacherFilters) {
  return Object.keys(filters).some((key) => Boolean(input[key]) && !filters[key as keyof TeacherFilters]);
}

export function teacherQuery(filters: TeacherFilters, extra: Record<string, string> = {}) {
  return new URLSearchParams(Object.entries({ ...filters, ...extra }).filter((entry): entry is [string, string] =>
    entry[1] !== undefined)).toString();
}

function scoped(teacherId: string, filter: TeacherFilters) {
  return {
    params: [teacherId, filter.student ?? null, filter.session ?? null, filter.level ?? null,
      filter.kind ?? null, filter.from ?? null, filter.to ?? null],
    text: `SELECT s.*, p.student_id, CASE WHEN s.topic_id = 'dining' THEN 'dining-hsk-' || s.hsk_level END AS scenario_id
           FROM teacher_students grant_row
           JOIN learner_profiles p ON p.user_id = grant_row.learner_id
           JOIN practice_sessions s ON s.user_id = p.user_id
           WHERE grant_row.teacher_id = $1
             AND ($2::uuid IS NULL OR p.student_id = $2)
             AND ($3::uuid IS NULL OR s.id = $3)
             AND ($4::text IS NULL OR s.hsk_level = $4)
             AND ($5::text IS NULL OR s.kind = $5)
             AND ($6::date IS NULL OR s.started_at >= ($6::date::timestamp AT TIME ZONE 'UTC'))
             AND ($7::date IS NULL OR s.started_at < (($7::date + 1)::timestamp AT TIME ZONE 'UTC'))`,
  };
}

export async function teacherStudents(database: Pool, teacherId: string) {
  const { rows } = await database.query<{ student_id: string; hsk_level: string; interface_language: string }>(
    `SELECT p.student_id, p.hsk_level, p.interface_language
     FROM teacher_students g JOIN learner_profiles p ON p.user_id = g.learner_id
     WHERE g.teacher_id = $1 ORDER BY p.student_id LIMIT 200`, [teacherId],
  );
  return rows;
}

export type TeacherSession = {
  id: string; student_id: string; kind: string; hsk_level: string; interface_language: string; topic_id: string | null;
  scenario_id: string | null; started_at: Date; ended_at: Date | null; summary: string | null; opening: string; count: number;
};

export async function teacherSessions(database: Pool, teacherId: string, filter: TeacherFilters) {
  const { text, params } = scoped(teacherId, filter);
  const { rows } = await database.query<TeacherSession>(
    `SELECT s.*, (SELECT count(*)::int FROM practice_turns t WHERE t.session_id = s.id) AS count
     FROM (${text}) s ORDER BY started_at DESC, id DESC LIMIT 200`, params,
  );
  return rows;
}

export type TeacherTurn = {
  position: number; learner_text: string; assistant_text: string; translation: string; hint: string; feedback: string;
  feedback_mode: string; original_asr: string | null; recording_id: string | null; revision_of: number | null;
  spoken: boolean | null; created_at: Date;
};

export async function teacherTurns(database: Pool, teacherId: string, sessionId: string) {
  const { rows } = await database.query<TeacherTurn>(
    `SELECT t.*, a.original_asr, a.recording_id
     FROM teacher_students g
     JOIN practice_sessions s ON s.user_id = g.learner_id
     JOIN practice_turns t ON t.session_id = s.id
     LEFT JOIN LATERAL (
       SELECT r.original_asr, r.recording_id FROM research_recordings r
       JOIN research_consents c ON c.id = r.consent_id AND c.revoked_at IS NULL
       WHERE r.session_id = t.session_id AND r.turn_position = t.position AND r.stored
     ) a ON true
     WHERE g.teacher_id = $1 AND s.id = $2 ORDER BY t.position`, [teacherId, sessionId],
  );
  return rows;
}

export async function teacherEvents(database: Pool, teacherId: string, sessionId: string) {
  const { rows } = await database.query<{ id: string; previous_mode: string; next_mode: string; created_at: Date }>(
    `SELECT e.id, e.previous_mode, e.next_mode, e.created_at FROM teacher_students g
     JOIN practice_sessions s ON s.user_id = g.learner_id
     JOIN practice_mode_events e ON e.session_id = s.id
     WHERE g.teacher_id = $1 AND s.id = $2 ORDER BY e.id LIMIT 200`, [teacherId, sessionId],
  );
  return rows;
}

export type OriginalRecording = {
  recording_id: string; session_id: string; student_id: string; turn_position: number;
  object_key: string; mime_type: string; sha256: string; size_bytes: number;
};
export const zipRecordingLimit = 10;

export async function teacherRecordings(database: Pool, teacherId: string, filter: TeacherFilters, recordingId?: string) {
  const { text, params } = scoped(teacherId, filter);
  const { rows } = await database.query<OriginalRecording>(
    `SELECT r.recording_id, r.session_id, s.student_id, r.turn_position, r.object_key, r.mime_type, r.sha256, r.size_bytes
     FROM (${text}) s JOIN research_recordings r ON r.session_id = s.id
     JOIN research_consents c ON c.id = r.consent_id AND c.revoked_at IS NULL
     WHERE r.stored AND r.turn_position IS NOT NULL AND ($8::uuid IS NULL OR r.recording_id = $8)
     ORDER BY r.captured_at DESC, r.recording_id
     LIMIT ${zipRecordingLimit + 1}`, [...params, recordingId ?? null],
  );
  return rows;
}

export const exportRowLimit = 5000;
export async function teacherExport(database: Pool, teacherId: string, filter: TeacherFilters) {
  const { text, params } = scoped(teacherId, filter);
  const { rows } = await database.query<Record<string, string | number | boolean | null>>(
    `WITH allowed AS (${text}), turn_counts AS (
       SELECT t.session_id, count(*)::int AS turn_count FROM practice_turns t
       JOIN allowed a ON a.id = t.session_id GROUP BY t.session_id
     ), records AS (
       SELECT 'session' AS record_type, s.id AS session_id, s.started_at AS observed_at,
              NULL::integer AS turn, NULL::text AS learner_reply, s.opening AS ai_reply,
              NULL::text AS hint, s.summary AS feedback, s.feedback_mode AS mode,
              NULL::text AS previous_mode, NULL::text AS original_asr, NULL::uuid AS recording_id,
              NULL::integer AS revision_of, NULL::boolean AS spoken, s.interface_language
       FROM allowed s
       UNION ALL
       SELECT 'turn', s.id, t.created_at, t.position, t.learner_text, t.assistant_text, t.hint, t.feedback,
              t.feedback_mode, NULL, r.original_asr, r.recording_id, t.revision_of, t.spoken, t.interface_language
       FROM allowed s JOIN practice_turns t ON t.session_id = s.id
       LEFT JOIN LATERAL (
         SELECT a.original_asr, a.recording_id FROM research_recordings a
         JOIN research_consents c ON c.id = a.consent_id AND c.revoked_at IS NULL
         WHERE a.session_id = t.session_id AND a.turn_position = t.position AND a.stored
       ) r ON true
       UNION ALL
       SELECT 'mode_change', s.id, e.created_at, NULL, NULL, NULL, NULL, NULL, e.next_mode, e.previous_mode,
              NULL, NULL, NULL, NULL, s.interface_language
       FROM allowed s JOIN practice_mode_events e ON e.session_id = s.id
     )
     SELECT r.record_type, a.student_id, r.session_id, a.kind, a.topic_id, a.scenario_id, a.hsk_level,
            r.interface_language, a.config_version, a.started_at, a.ended_at, a.ended_at IS NOT NULL AS completed, COALESCE(tc.turn_count, 0) AS turn_count,
            r.observed_at, r.turn, r.learner_reply, r.ai_reply, r.hint, r.feedback, r.mode, r.previous_mode,
            r.original_asr, r.recording_id, r.revision_of, r.spoken
     FROM records r JOIN allowed a ON a.id = r.session_id
     LEFT JOIN turn_counts tc ON tc.session_id = r.session_id
     ORDER BY a.started_at DESC, r.session_id, r.observed_at, r.record_type, r.turn
     LIMIT ${exportRowLimit + 1}`, params,
  );
  return rows;
}
