import Link from "next/link";
import { getViewer } from "@/lib/preferences";
import { levels } from "@/lib/learner";
import { practiceKinds } from "@/lib/practice";
import { invalidTeacherFilters, teacherAccess, teacherFilters, teacherQuery, teacherSessions, teacherStudents } from "@/lib/teacher";
import { teacherCopy } from "@/lib/teacher-i18n";

export default async function TeacherPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { preferences: { locale } } = await getViewer();
  const t = teacherCopy[locale];
  const access = await teacherAccess();
  if (access.status !== 200) return <section className="subpage">
    <h1>{t.title}</h1>
    <div className="panel">{access.status === 401 ? <Link className="button" href="/account?next=teacher">{t.login}</Link>
      : <p>{access.status === 403 ? t.denied : t.unavailable}</p>}</div>
  </section>;

  const input = await searchParams;
  const filter = teacherFilters(input);
  const invalid = invalidTeacherFilters(input, filter);
  const [students, sessions] = await Promise.all([
    teacherStudents(access.database, access.teacherId),
    invalid ? [] : teacherSessions(access.database, access.teacherId, filter),
  ]);
  const date = new Intl.DateTimeFormat(locale, { dateStyle: "medium", timeStyle: "short", timeZone: "UTC" });
  const formats = { csv: "CSV", xlsx: "Excel", json: "JSON", audio: t.audioZip };

  return <section className="subpage teacher">
    <Link className="back" href="/account?next=teacher">{t.account}</Link>
    <h1>{t.title}</h1>
    <details className="panel">
      <summary>{t.students} · {students.length}</summary>
      {students.length ? <ul>{students.map((student) => (
        <li key={student.student_id}>
          <Link href={`/teacher?${teacherQuery({ student: student.student_id })}`}>{student.student_id}</Link>
          {" · HSK "}{student.hsk_level} · {student.interface_language}
        </li>
      ))}</ul> : <p>{t.none}</p>}
    </details>
    <section className="panel teacher-section">
      <h2>{t.sessions}</h2>
      <form action="/teacher" method="get" className="teacher-filters">
        <label>{t.student}<input name="student" defaultValue={filter.student} list="teacher-students" /></label>
        <datalist id="teacher-students">{students.map((student) => <option key={student.student_id} value={student.student_id} />)}</datalist>
        <label>{t.level}<select name="level" defaultValue={filter.level ?? ""}>
          <option value="">{t.all}</option>{levels.map((level) => <option key={level} value={level}>HSK {level}</option>)}
        </select></label>
        <label>{t.kind}<select name="kind" defaultValue={filter.kind ?? ""}>
          <option value="">{t.all}</option>{practiceKinds.map((kind) => <option key={kind} value={kind}>{t.kinds[kind]}</option>)}
        </select></label>
        <label>{t.from}<input type="date" name="from" defaultValue={filter.from} /></label>
        <label>{t.to}<input type="date" name="to" defaultValue={filter.to} /></label>
        <div className="lesson-actions"><button className="button" type="submit">{t.filter}</button>
          <Link className="lesson-secondary" href="/teacher">{t.reset}</Link></div>
      </form>
      {invalid && <p className="form-error" role="alert">{t.invalidFilter}</p>}
      {!invalid && <div className="lesson-actions teacher-section">
        {Object.entries(formats).map(([format, label]) => (
          <a className="lesson-secondary" key={format} href={`/api/teacher/export?${teacherQuery(filter, { format })}`}>{label}</a>
        ))}
      </div>}
      <p className="status teacher-section">{t.limits}</p>
      {sessions.length ? <div className="teacher-table"><table>
        <thead><tr>{[t.student, t.kind, t.level, t.started, t.status, t.turns, t.detail].map((label) => <th key={label} scope="col">{label}</th>)}</tr></thead>
        <tbody>{sessions.map((session) => (
          <tr key={session.id}>
            <td>{session.student_id}</td><td>{t.kinds[session.kind as keyof typeof t.kinds]}</td>
            <td>{session.hsk_level}</td><td>{date.format(session.started_at)}</td>
            <td>{session.ended_at ? t.completed : t.open}</td><td>{session.count}</td>
            <td><Link href={`/teacher/${session.id}`}>{t.inspect}</Link></td>
          </tr>
        ))}</tbody>
      </table></div> : <p>{t.none}</p>}
    </section>
  </section>;
}
