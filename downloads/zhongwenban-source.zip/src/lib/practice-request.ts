import { getDatabase } from "./db";
import { getViewer } from "./preferences";

export function practiceFailure(status: number) {
  return Response.json({ ok: false }, { status });
}

export async function authorizePractice(request: Request) {
  const database = getDatabase();
  const url = process.env.BETTER_AUTH_URL;
  if (!database || !url) return { error: practiceFailure(503) } as const;
  if (request.headers.get("origin") !== new URL(url).origin) {
    return { error: practiceFailure(403) } as const;
  }

  const { user, needsSetup, preferences } = await getViewer();
  if (!user || needsSetup) return { error: practiceFailure(401) } as const;
  return { database, user, preferences } as const;
}

export function boundedPracticeBody(request: Request, limit: number) {
  if (!request.body || Number(request.headers.get("content-length")) > limit) return null;
  let size = 0;
  const bounded = request.body.pipeThrough(new TransformStream<Uint8Array>({
    transform(chunk, controller) {
      size += chunk.byteLength;
      if (size > limit) controller.error(new Error("Too much data"));
      else controller.enqueue(chunk);
    },
  }));
  const contentType = request.headers.get("content-type") ?? "";
  return new Response(bounded, { headers: { "Content-Type": contentType } });
}

export async function readPracticeJson(request: Request) {
  if (!request.headers.get("content-type")?.startsWith("application/json")) return null;
  const body = boundedPracticeBody(request, 4096);
  const data: unknown = await body?.json().catch(() => null);
  return data && typeof data === "object" && !Array.isArray(data) ? data as Record<string, unknown> : null;
}
