import { betterAuth } from "better-auth";
import { toNextJsHandler } from "better-auth/next-js";
import { getDatabase } from "./db";

function createAuth() {
  const database = getDatabase();
  const baseURL = process.env.BETTER_AUTH_URL;
  const secret = process.env.BETTER_AUTH_SECRET;
  if (!database || !baseURL || !secret) return undefined;

  return betterAuth({
    appName: "中文伴",
    baseURL,
    secret,
    database,
    emailAndPassword: {
      enabled: true, minPasswordLength: 12, maxPasswordLength: 128,
      disableSignUp: process.env.AUTH_DISABLE_SIGNUP === "true",
    },
    rateLimit: { enabled: true, storage: "database", window: 60, max: 120 },
  });
}

let auth: ReturnType<typeof createAuth>;

export function getAuth() {
  auth ??= createAuth();
  return auth;
}

export async function handleAuth(request: Request) {
  const instance = getAuth();
  if (!instance) return Response.json({ code: "AUTH_NOT_CONFIGURED" }, { status: 503 });

  const handler = toNextJsHandler(instance);
  return (request.method === "POST" ? handler.POST : handler.GET)(request);
}
