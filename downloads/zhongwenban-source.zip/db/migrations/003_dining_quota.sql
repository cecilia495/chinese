CREATE TABLE dining_practice_quota (
  user_id text PRIMARY KEY REFERENCES learner_profiles(user_id) ON DELETE CASCADE,
  window_start timestamptz NOT NULL DEFAULT now(),
  requests integer NOT NULL DEFAULT 1 CHECK (requests BETWEEN 1 AND 8)
);
