import { authorizePractice, practiceFailure as fail, readPracticeJson } from "@/lib/practice-request";
import { isSessionId } from "@/lib/practice";
import { findVocabulary } from "@/lib/vocabulary";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const access = await authorizePractice(request);
    if (access.error) return access.error;
    const { database, user, preferences } = access;
    const input = await readPracticeJson(request);
    if (!input) return fail(400);

    if (input.action === "complete") {
      const { id, level, steps } = input;
      if (!isSessionId(id) || level !== preferences.level || (level !== "1" && level !== "2" && level !== "3") ||
          !Array.isArray(steps) || steps.length > 4 || new Set(steps).size !== steps.length ||
          steps.some((step) => ![0, 1, 2, 3].includes(step))) return fail(400);
      await database.query(
        `INSERT INTO lesson_completions (user_id, id, topic_id, hsk_level, completed_steps)
         VALUES ($1, $2, 'dining', $3, $4) ON CONFLICT (user_id, id) DO NOTHING`,
        [user.id, id, level, steps],
      );
      return Response.json({ ok: true });
    }

    if (typeof input.key !== "string") return fail(400);
    if (input.action === "favorite" && typeof input.saved === "boolean") {
      if (input.saved) {
        const entry = findVocabulary(input.key);
        if (!entry) return fail(404);
        await database.query(
          `INSERT INTO user_vocabulary (user_id, word_key, snapshot)
           VALUES ($1, $2, $3) ON CONFLICT (user_id, word_key) DO NOTHING`, [user.id, entry.key, JSON.stringify(entry)],
        );
      } else {
        await database.query("DELETE FROM user_vocabulary WHERE user_id = $1 AND word_key = $2", [user.id, input.key]);
      }
      return Response.json({ ok: true });
    }

    if (input.action === "review" && typeof input.remembered === "boolean" && isSessionId(input.id)) {
      const result = await database.query(
        `WITH saved AS (
           SELECT user_id, word_key FROM user_vocabulary WHERE user_id = $1 AND word_key = $2 FOR UPDATE
         ), attempt AS (
           INSERT INTO review_attempts (id, user_id, word_key, remembered)
           SELECT $3, user_id, word_key, $4 FROM saved
           ON CONFLICT (user_id, id) DO NOTHING RETURNING user_id, word_key
         ), scheduled AS (
           UPDATE user_vocabulary v
           SET due_at = now() + CASE WHEN $4 THEN interval '1 day' ELSE interval '10 minutes' END
           FROM attempt a WHERE v.user_id = a.user_id AND v.word_key = a.word_key
         )
         SELECT word_key FROM saved`, [user.id, input.key, input.id, input.remembered],
      );
      return result.rowCount ? Response.json({ ok: true }) : fail(404);
    }
    return fail(400);
  } catch {
    return fail(503);
  }
}
