import pg from "pg";

for (const file of [".env.local", ".env"]) {
  try {
    process.loadEnvFile(file);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
}

const [action, teacher, learner] = process.argv.slice(2);
const scoped = action === "assign" || action === "unassign";
if (!process.env.DATABASE_URL || !teacher || !["grant", "revoke", "assign", "unassign"].includes(action) ||
    (scoped ? !learner : Boolean(learner))) {
  console.error("Set DATABASE_URL, then run: npm run teacher:access -- grant|revoke teacher-email OR assign|unassign teacher-email learner-email");
  process.exit(1);
}

const database = new pg.Client({ connectionString: process.env.DATABASE_URL, connectionTimeoutMillis: 5000 });
try {
  await database.connect();
  const { rows } = await database.query('SELECT id FROM "user" WHERE lower(email) = lower($1)', [teacher]);
  const id = rows[0]?.id;
  if (!id) throw new Error("Teacher account not found");
  if (action === "grant") {
    await database.query("INSERT INTO teacher_roles (user_id) VALUES ($1) ON CONFLICT DO NOTHING", [id]);
  } else if (action === "revoke") {
    await database.query("DELETE FROM teacher_roles WHERE user_id = $1", [id]);
  } else {
    const learnerQuery = await database.query(
      'SELECT p.user_id FROM learner_profiles p JOIN "user" u ON u.id = p.user_id WHERE lower(u.email) = lower($1)', [learner],
    );
    const learnerId = learnerQuery.rows[0]?.user_id;
    if (!learnerId) throw new Error("Learner profile not found");
    const sql = action === "assign"
      ? "INSERT INTO teacher_students (teacher_id, learner_id) VALUES ($1, $2) ON CONFLICT DO NOTHING"
      : "DELETE FROM teacher_students WHERE teacher_id = $1 AND learner_id = $2";
    await database.query(sql, [id, learnerId]);
  }
  console.log("Teacher access updated.");
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
} finally {
  await database.end();
}
