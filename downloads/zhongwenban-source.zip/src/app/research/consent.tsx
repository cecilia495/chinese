"use client";

import { useState } from "react";
import type { Locale } from "@/lib/i18n";
import { researchCopy } from "@/lib/research-i18n";

export function Consent({ locale, active, recordings, configured, version }: {
  locale: Locale; active: boolean; recordings: number; configured: boolean; version: number;
}) {
  const t = researchCopy[locale];
  const [status, setStatus] = useState({ active, recordings });
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(false);

  async function update(action: "grant" | "withdraw") {
    setBusy(true);
    setError(false);
    try {
      const response = await fetch("/api/research", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, version }),
      });
      if (!response.ok) throw new Error("Consent update failed");
      setStatus(await response.json());
      setConfirm(false);
    } catch {
      setError(true);
    } finally {
      setBusy(false);
    }
  }

  return <section className="panel">
    <p>{t.notice}</p>
    <p role="status">{status.active ? t.active : t.off}</p>
    {!configured && <p>{t.unavailable}</p>}
    {!status.active && status.recordings > 0 && <p role="status">{t.pending}</p>}
    {error && <p className="form-error" role="alert">{t.error}</p>}
    <div className="lesson-actions">
      {!status.active && configured && !status.recordings && <button type="button" className="button" disabled={busy}
        onClick={() => update("grant")}>{busy ? t.working : t.grant}</button>}
      {(status.active || status.recordings > 0) && (confirm ? <>
        <button type="button" className="button" disabled={busy} onClick={() => update("withdraw")}>{busy ? t.working : t.confirm}</button>
        <button type="button" className="lesson-secondary" disabled={busy} onClick={() => setConfirm(false)}>{t.cancel}</button>
      </> : <button type="button" className="lesson-secondary" onClick={() => setConfirm(true)}>{status.active ? t.withdraw : t.retry}</button>)}
    </div>
  </section>;
}
