import { createHash } from "node:crypto";
import { strToU8, zipSync } from "fflate";
import { privateDownloadHeaders, researchCsv, researchExcel } from "@/lib/research-export";
import { readOriginal } from "@/lib/research-storage";
import { exportRowLimit, invalidTeacherFilters, teacherAccess, teacherExport, teacherFilters, teacherRecordings, zipRecordingLimit } from "@/lib/teacher";

export const runtime = "nodejs";

function download(body: BodyInit, type: string, name: string) {
  return new Response(body, { headers: {
    ...privateDownloadHeaders, "Content-Type": type, "Content-Disposition": `attachment; filename="${name}"`,
  } });
}

function reject(status: number, code: string) {
  return Response.json({ code }, { status, headers: privateDownloadHeaders });
}

export async function GET(request: Request) {
  try {
    const access = await teacherAccess();
    if (access.status !== 200) return reject(access.status, "ACCESS_REQUIRED");
    const input = Object.fromEntries(new URL(request.url).searchParams);
    const filter = teacherFilters(input);
    if (invalidTeacherFilters(input, filter)) {
      return reject(400, "INVALID_FILTER");
    }

    if (input.format === "audio") {
      const recordings = await teacherRecordings(access.database, access.teacherId, filter);
      if (recordings.length > zipRecordingLimit) return reject(413, "NARROW_AUDIO_FILTERS");
      const files: Record<string, Uint8Array> = {};
      const manifest = [];
      const extensions: Record<string, string> = { "audio/webm": "webm", "audio/ogg": "ogg", "audio/wav": "wav", "audio/mp4": "m4a" };
      for (const recording of recordings) {
        // Check assignment and consent again before reading each original.
        const [current] = await teacherRecordings(access.database, access.teacherId, filter, recording.recording_id);
        if (!current) continue;
        const audio = await readOriginal(current.object_key);
        if (!audio.Body) return reject(502, "RECORDING_UNAVAILABLE");
        const bytes = await audio.Body.transformToByteArray();
        if (bytes.length !== current.size_bytes || createHash("sha256").update(bytes).digest("hex") !== current.sha256) {
          return reject(502, "RECORDING_INTEGRITY_FAILED");
        }
        const filename = `${current.recording_id}.${extensions[current.mime_type]}`;
        files[filename] = bytes;
        const { object_key: _, ...publicMetadata } = current;
        void _;
        manifest.push({ filename, ...publicMetadata });
      }
      // Consent can change while building the archive. Fail closed before releasing any bytes.
      if (manifest.length) {
        const latest = await teacherRecordings(access.database, access.teacherId, filter);
        const allowed = new Set(latest.map((item) => item.recording_id));
        if (manifest.some((item) => !allowed.has(item.recording_id))) return reject(409, "RETRY_EXPORT");
      }
      files["manifest.json"] = strToU8(JSON.stringify(manifest, null, 2));
      return download(new Uint8Array(zipSync(files, { level: 0 })), "application/zip", "recordings.zip");
    }

    if (!["csv", "xlsx", "json"].includes(input.format)) return reject(400, "INVALID_FORMAT");
    const rows = await teacherExport(access.database, access.teacherId, filter);
    if (rows.length > exportRowLimit) return reject(413, "NARROW_DATA_FILTERS");
    if (input.format === "csv") return download(researchCsv(rows), "text/csv; charset=utf-8", "practice.csv");
    if (input.format === "xlsx") return download(new Uint8Array(researchExcel(rows)), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "practice.xlsx");
    return download(JSON.stringify(rows, null, 2), "application/json; charset=utf-8", "practice.json");
  } catch {
    return reject(502, "EXPORT_UNAVAILABLE");
  }
}
