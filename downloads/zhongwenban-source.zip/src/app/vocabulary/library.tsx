"use client";

import { useRef, useState } from "react";
import { LessonAudio } from "@/app/learn/lesson-audio";
import { diningCopy } from "@/lib/dining-i18n";
import { learningCopy } from "@/lib/learning-i18n";
import { saveLearning } from "@/lib/learning-client";
import type { Locale } from "@/lib/i18n";
import type { SavedWord } from "@/lib/learning-store";
import { Favorite } from "./favorite";

export function Library({ initial, locale }: { initial: SavedWord[]; locale: Locale }) {
  const t = learningCopy[locale];
  const [words, setWords] = useState(initial);
  const [reviewing, setReviewing] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(false);
  const requestId = useRef<string | undefined>(undefined);
  const next = words.find((word) => word.due);

  async function review(remembered: boolean) {
    if (!next || busy) return;
    setBusy(true);
    setError(false);
    try {
      requestId.current ??= crypto.randomUUID();
      await saveLearning({ action: "review", key: next.key, id: requestId.current, remembered });
      requestId.current = undefined;
      setWords((current) => current.map((word) => word.key === next.key ? { ...word, due: false } : word));
      setRevealed(false);
    } catch {
      setError(true);
    } finally {
      setBusy(false);
    }
  }

  if (reviewing) return (
    <section className="panel">
      <div className="lesson-actions">
        <button className="lesson-secondary" type="button" disabled={busy} onClick={() => {
          setReviewing(false); setRevealed(false); setError(false);
        }}>{t.backToWords}</button>
      </div>
      {next ? (
        <>
          <h2 className="lesson-phrase learning-heading" lang="zh-Hans">{next.word}</h2>
          {revealed ? (
            <>
              <p lang="zh-Latn">{next.pinyin}</p>
              <p>{next.definition[locale]}</p>
              <div className="lesson-actions">
                <button type="button" className="button" disabled={busy} onClick={() => review(true)}>{t.remembered}</button>
                <button type="button" className="lesson-secondary" disabled={busy} onClick={() => review(false)}>{t.again}</button>
              </div>
            </>
          ) : <button className="button" type="button" onClick={() => setRevealed(true)}>{t.reveal}</button>}
        </>
      ) : <p className="learning-heading">{t.noDue}</p>}
      {error && <p className="form-error" role="alert">{t.error}</p>}
    </section>
  );

  return (
    <>
      <button className="button" type="button" disabled={!next} onClick={() => setReviewing(true)}>{t.review}</button>
      {!words.length ? <p className="learning-heading">{t.empty}</p>
        : <ul className="learning-list">
          {words.map((word) => (
            <li className="panel" key={word.key}>
              <p className="status">{t.source} · HSK {word.level}{word.due ? ` · ${t.vocabularyDue}` : ""}</p>
              <h2 lang="zh-Hans">{word.word}</h2>
              <p lang="zh-Latn">{word.pinyin}</p>
              <p>{word.definition[locale]}</p>
              <blockquote lang="zh-Hans">{word.example}</blockquote>
              {locale === "en" && <p>{word.exampleEn}</p>}
              <LessonAudio src={word.audio} t={diningCopy[locale]} example />
              <div className="lesson-actions learning-heading">
                <Favorite locale={locale} wordKey={word.key} saved commit={() => {
                  setWords((current) => current.filter((entry) => entry.key !== word.key));
                  requestId.current = undefined;
                }} />
              </div>
            </li>
          ))}
        </ul>}
    </>
  );
}
