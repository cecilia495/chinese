import { createHash } from "node:crypto";
import type { Pool, PoolClient } from "pg";
import { deleteOriginal, researchStorageConfigured, saveOriginal } from "./research-storage";

export const consentVersion = 1;

export async function researchStatus(database: Pool, userId: string) {
  const { rows } = await database.query<{ active: boolean; recordings: number }>(
    `SELECT EXISTS (SELECT 1 FROM research_consents WHERE user_id = $1 AND revoked_at IS NULL) AS active,
       (SELECT count(*)::int FROM research_recordings r JOIN research_consents c ON c.id = r.consent_id
        WHERE c.user_id = $1) AS recordings`, [userId],
  );
  return rows[0];
}

async function withLearnerLock<T>(database: Pool, userId: string, work: (client: PoolClient) => Promise<T>) {
  const client = await database.connect();
  try {
    await client.query("BEGIN");
    const locked = await client.query("SELECT user_id FROM learner_profiles WHERE user_id = $1 FOR UPDATE", [userId]);
    if (!locked.rowCount) throw new Error("Learner missing");
    const result = await work(client);
    await client.query("COMMIT");
    return result;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function grantRecordingConsent(database: Pool, userId: string) {
  await withLearnerLock(database, userId, (client) => client.query(
    `INSERT INTO research_consents (user_id, policy_version) VALUES ($1, $2)
     ON CONFLICT (user_id) WHERE revoked_at IS NULL DO NOTHING`, [userId, consentVersion],
  ));
}

export async function withdrawRecordingConsent(database: Pool, userId: string) {
  await withLearnerLock(database, userId, (client) => client.query(
    "UPDATE research_consents SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL", [userId],
  ));
  // A failed object deletion leaves a manifest row for retry. Revoked data is already hidden.
  const { rows } = await database.query<{ id: string; object_key: string }>(
    `SELECT r.id, r.object_key FROM research_recordings r JOIN research_consents c ON c.id = r.consent_id
     WHERE c.user_id = $1 AND c.revoked_at IS NOT NULL ORDER BY r.captured_at LIMIT 25`, [userId],
  );
  const results = await Promise.allSettled(rows.map(async (row) => {
    await deleteOriginal(row.object_key);
    await database.query("DELETE FROM research_recordings WHERE id = $1", [row.id]);
  }));
  const { rows: [remaining] } = await database.query<{ count: number }>(
    `SELECT count(*)::int AS count FROM research_recordings r JOIN research_consents c ON c.id = r.consent_id
     WHERE c.user_id = $1 AND c.revoked_at IS NOT NULL`, [userId],
  );
  return { pending: remaining.count, failure: results.some((result) => result.status === "rejected") };
}

export function originalAudioMatches(bytes: Uint8Array, mime: string) {
  const data = Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (mime === "audio/webm") return data.subarray(0, 4).equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3]));
  if (mime === "audio/ogg") return data.toString("ascii", 0, 4) === "OggS";
  if (mime === "audio/mp4") return data.toString("ascii", 4, 8) === "ftyp";
  return mime === "audio/wav" && data.toString("ascii", 0, 4) === "RIFF" && data.toString("ascii", 8, 12) === "WAVE";
}

export async function persistResearchAudio(database: Pool, data: {
  userId: string; sessionId: string; receiptId: string; audio: File; text: string; consentId: string;
}) {
  if (!researchStorageConfigured()) return "failed";
  const { userId, sessionId, receiptId, consentId, audio, text } = data;
  const bytes = new Uint8Array(await audio.arrayBuffer());
  const mime = audio.type.split(";")[0].toLowerCase();
  if (!originalAudioMatches(bytes, mime)) return "failed";
  const hash = createHash("sha256").update(bytes).digest("hex");
  const key = `research/${sessionId}/${receiptId}`;

  const reserved = await withLearnerLock(database, userId, (client) => client.query(
      `INSERT INTO research_recordings
         (id, consent_id, session_id, object_key, mime_type, size_bytes, sha256, original_asr)
       SELECT $1, c.id, s.id, $2, $3, $4, $5, $6
       FROM research_consents c JOIN practice_sessions s ON s.user_id = c.user_id
       WHERE c.user_id = $7 AND c.id = $8 AND c.revoked_at IS NULL AND c.policy_version = $9
         AND s.id = $10 AND s.ended_at IS NULL RETURNING id`,
      [receiptId, key, mime, bytes.length, hash, text, userId, consentId, consentVersion, sessionId],
  ));
  if (!reserved.rowCount) return "off";

  return withLearnerLock(database, userId, async (client) => {
    const eligible = await client.query(
      `SELECT r.id FROM research_recordings r
       JOIN research_consents c ON c.id = r.consent_id AND c.revoked_at IS NULL
       JOIN practice_sessions s ON s.id = r.session_id AND s.ended_at IS NULL
       WHERE r.id = $1 AND c.user_id = $2`, [receiptId, userId],
    );
    if (!eligible.rowCount) return "off";
    // The committed manifest can still be used to remove a partially completed upload.
    try {
      await saveOriginal(key, bytes, mime);
    } catch {
      return "failed";
    }
    await client.query("UPDATE research_recordings SET stored = true WHERE id = $1", [receiptId]);
    return "saved";
  });
}

export async function discardUnsubmittedRecordings(database: Pool, userId: string, sessionId: string) {
  await withLearnerLock(database, userId, async (client) => {
    const { rows } = await client.query<{ id: string; object_key: string }>(
      `SELECT r.id, r.object_key FROM research_recordings r
       JOIN research_consents c ON c.id = r.consent_id
       JOIN practice_sessions s ON s.id = r.session_id
       WHERE s.id = $1 AND s.user_id = $2 AND s.ended_at IS NOT NULL
         AND c.user_id = $2 AND r.turn_position IS NULL`, [sessionId, userId],
    );
    const deleted = (await Promise.allSettled(rows.map(async (row) => {
      await deleteOriginal(row.object_key);
      return row.id;
    }))).flatMap((result) => result.status === "fulfilled" ? [result.value] : []);
    if (deleted.length) await client.query("DELETE FROM research_recordings WHERE id = ANY($1::uuid[])", [deleted]);
  });
}
