import type { Pool } from "pg";
import type { VocabularyEntry } from "./vocabulary";

export type SavedWord = VocabularyEntry & { due: boolean };

export async function savedVocabulary(database: Pool, userId: string) {
  const { rows } = await database.query<{ snapshot: VocabularyEntry; due: boolean }>(
    `SELECT snapshot, due_at <= now() AS due
     FROM user_vocabulary WHERE user_id = $1 ORDER BY due_at, saved_at, word_key`, [userId],
  );
  return rows.map(({ snapshot, due }) => ({ ...snapshot, due }));
}

export async function getLearningProgress(database: Pool, userId: string) {
  const { rows } = await database.query<{
    levels: ("1" | "2" | "3")[];
    lessonRuns: number;
    tasks: number;
    sessions: number;
    spoken: number;
    seconds: number;
    words: number;
    due: number;
    feedback: string | null;
  }>(
    `WITH completed AS (
       SELECT s.* FROM practice_sessions s
       WHERE s.user_id = $1 AND s.ended_at IS NOT NULL
         AND EXISTS (SELECT 1 FROM practice_turns t WHERE t.session_id = s.id)
     )
     SELECT
       ARRAY(SELECT DISTINCT hsk_level FROM lesson_completions
             WHERE user_id = $1 AND cardinality(completed_steps) = 4 ORDER BY hsk_level) AS levels,
       (SELECT count(*)::int FROM lesson_completions WHERE user_id = $1) AS "lessonRuns",
       (SELECT count(*)::int FROM completed WHERE kind = 'topic') AS tasks,
       (SELECT count(*)::int FROM completed) AS sessions,
       (SELECT count(*)::int FROM completed s WHERE EXISTS (
          SELECT 1 FROM practice_turns t WHERE t.session_id = s.id AND t.spoken IS TRUE))
       + (SELECT count(*)::int FROM lesson_completions
          WHERE user_id = $1 AND 2 = ANY(completed_steps)) AS spoken,
       COALESCE((SELECT floor(sum(extract(epoch FROM ended_at - started_at)))::int FROM completed), 0) AS seconds,
       (SELECT count(*)::int FROM user_vocabulary WHERE user_id = $1) AS words,
       (SELECT count(*)::int FROM user_vocabulary WHERE user_id = $1 AND due_at <= now()) AS due,
       (SELECT value FROM (
          SELECT summary AS value, ended_at AS observed_at FROM completed WHERE summary IS NOT NULL
          UNION ALL
          SELECT t.feedback, t.created_at FROM practice_turns t
          JOIN completed s ON s.id = t.session_id WHERE t.feedback <> ''
        ) feedback_history ORDER BY observed_at DESC LIMIT 1) AS feedback`,
    [userId],
  );
  return rows[0];
}
