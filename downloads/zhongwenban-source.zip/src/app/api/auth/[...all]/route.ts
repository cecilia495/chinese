import { handleAuth } from "@/lib/auth";

export const runtime = "nodejs";
export { handleAuth as GET, handleAuth as POST };
