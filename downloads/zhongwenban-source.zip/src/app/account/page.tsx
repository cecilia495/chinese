import Link from "next/link";
import { redirect } from "next/navigation";
import { dictionaries } from "@/lib/i18n";
import { teacherCopy } from "@/lib/teacher-i18n";
import { getViewer } from "@/lib/preferences";
import { AuthForm, SignOut } from "./auth-form";

export default async function AccountPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const nextTeacher = (await searchParams).next === "teacher";
  const { preferences, user, accountsEnabled, needsSetup } = await getViewer();
  if (needsSetup && !nextTeacher) redirect("/settings");

  const t = dictionaries[preferences.locale];

  return (
    <section className="subpage">
      <Link className="back" href={nextTeacher ? "/teacher" : "/"}>{nextTeacher ? teacherCopy[preferences.locale].back : t.back}</Link>
      <h1>{t.account.title}</h1>
      {user ? (
        <div className="panel">
          <p>{user.email}</p>
          <SignOut labels={t.account} />
        </div>
      ) : accountsEnabled ? <AuthForm labels={t.account} destination={nextTeacher ? "/teacher" : "/"} allowRegistration={process.env.AUTH_DISABLE_SIGNUP !== "true"} /> : <div className="panel"><p>{t.account.disabled}</p></div>}
    </section>
  );
}
