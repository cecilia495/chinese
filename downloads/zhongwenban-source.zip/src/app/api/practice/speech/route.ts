import { isSessionId, maxAudioBytes } from "@/lib/practice";
import { practiceServices, recognizeMandarin, synthesizeMandarin } from "@/lib/practice-provider";
import { authorizePractice, boundedPracticeBody, practiceFailure as fail, readPracticeJson } from "@/lib/practice-request";
import { consentVersion, persistResearchAudio } from "@/lib/research";
import { consumeQuota, loadPractice } from "@/lib/practice-store";

export const runtime = "nodejs";

const extensions = new Map([
  ["audio/webm", "webm"], ["audio/ogg", "ogg"], ["audio/mp4", "m4a"], ["audio/wav", "wav"],
]);

export async function POST(request: Request) {
  try {
    const access = await authorizePractice(request);
    if (access.error) return access.error;
    const { database, user } = access;
    const services = practiceServices();

    if (request.headers.get("content-type")?.startsWith("multipart/form-data;")) {
      if (!services.asr) return fail(503);
      const body = boundedPracticeBody(request, maxAudioBytes + 2048);
      if (!body) return fail(413);
      const form = await body.formData().catch(() => null);
      if (!form) return fail(400);
      const id = form.get("id");
      const audio = form.get("audio");
      if (!isSessionId(id) || !(audio instanceof File) || audio.size === 0 || audio.size > maxAudioBytes) return fail(400);
      const extension = extensions.get(audio.type.split(";")[0].toLowerCase());
      if (!extension) return fail(415);
      const session = await loadPractice(database, user.id, id);
      if (!session || session.ended) return fail(404);
      if (!await consumeQuota(database, user.id, "asr")) return fail(429);

      const { rows: [consent] } = await database.query<{ id: string }>(
        "SELECT id FROM research_consents WHERE user_id = $1 AND revoked_at IS NULL AND policy_version = $2",
        [user.id, consentVersion],
      );

      let text: string;
      try {
        text = await recognizeMandarin(audio, extension);
      } catch {
        return fail(502);
      }
      const { rows } = await database.query<{ id: string }>(
        `WITH expire AS (
           DELETE FROM practice_transcriptions WHERE session_id = $1 AND created_at <= now() - interval '1 hour'
         )
         INSERT INTO practice_transcriptions (session_id) VALUES ($1) RETURNING id`, [session.id],
      );
      const transcriptionId = rows[0].id;
      const research = consent ? await persistResearchAudio(database, {
        userId: user.id, sessionId: session.id, receiptId: transcriptionId, audio, text, consentId: consent.id,
      }).catch(() => "failed") : "off";
      return Response.json({ text, transcriptionId, research });
    }

    if (!services.tts) return fail(503);
    const input = await readPracticeJson(request);
    if (!input || !isSessionId(input.id) || !Number.isInteger(input.position)) return fail(400);
    const session = await loadPractice(database, user.id, input.id);
    if (!session) return fail(404);
    const speech = input.position === 0 ? session.opening : session.turns.find((turn) => turn.position === input.position)?.reply;
    if (!speech) return fail(404);
    if (!await consumeQuota(database, user.id, "tts")) return fail(429);

    try {
      return new Response(await synthesizeMandarin(speech, session.voice), {
        headers: { "Content-Type": "audio/mpeg", "Cache-Control": "no-store" },
      });
    } catch {
      return fail(502);
    }
  } catch {
    return fail(503);
  }
}
