import { DeleteObjectCommand, GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";

let client: S3Client | undefined;

export function researchStorageConfigured() {
  return Boolean(process.env.RESEARCH_S3_BUCKET && process.env.RESEARCH_S3_REGION);
}

function storage() {
  const Bucket = process.env.RESEARCH_S3_BUCKET;
  const region = process.env.RESEARCH_S3_REGION;
  if (!Bucket || !region) throw new Error("Research storage unavailable");
  client ??= new S3Client({
    region, endpoint: process.env.RESEARCH_S3_ENDPOINT || undefined,
    forcePathStyle: process.env.RESEARCH_S3_PATH_STYLE === "true", maxAttempts: 2,
  });
  return { client, Bucket };
}

export async function saveOriginal(Key: string, Body: Uint8Array, ContentType: string) {
  const { client, Bucket } = storage();
  await client.send(new PutObjectCommand({ Bucket, Key, Body, ContentType }), { abortSignal: AbortSignal.timeout(8000) });
}

export async function readOriginal(Key: string, range?: string) {
  const { client, Bucket } = storage();
  return client.send(new GetObjectCommand({ Bucket, Key, Range: range }), { abortSignal: AbortSignal.timeout(8000) });
}

export async function deleteOriginal(Key: string) {
  const { client, Bucket } = storage();
  await client.send(new DeleteObjectCommand({ Bucket, Key }), { abortSignal: AbortSignal.timeout(8000) });
}
