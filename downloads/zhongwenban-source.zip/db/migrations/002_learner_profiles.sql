CREATE TABLE learner_profiles (
  user_id text PRIMARY KEY REFERENCES "user"(id) ON DELETE CASCADE,
  hsk_level text NOT NULL CHECK (hsk_level IN ('1', '2', '3', '4', '5', '6', '7–9')),
  interface_language text NOT NULL CHECK (interface_language IN ('en', 'zh')),
  voice_id text,
  speech_rate numeric(3,2) NOT NULL DEFAULT 1.00 CHECK (speech_rate IN (0.75, 0.85, 1.00, 1.10)),
  default_feedback_mode text NOT NULL DEFAULT 'gentle' CHECK (default_feedback_mode IN ('natural', 'gentle', 'key', 'detailed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
