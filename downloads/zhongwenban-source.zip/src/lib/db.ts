import { Pool } from "pg";

let pool: Pool | undefined;

export function getDatabase(): Pool | undefined {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) return undefined;

  if (!pool) {
    pool = new Pool({ connectionString, connectionTimeoutMillis: 2500, query_timeout: 2500 });
    pool.on("error", () => console.error("An idle PostgreSQL connection failed"));
  }
  return pool;
}
