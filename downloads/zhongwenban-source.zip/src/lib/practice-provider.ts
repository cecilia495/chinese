import type { Locale } from "./i18n";
import type { Level } from "./learner";
import type { FeedbackMode, PracticeSession } from "./practice";

const difficulties: Record<Level, string> = {
  "1": "使用最常见的词和简单句。回复优先保持在25个汉字以内，每次只问一个具体问题。",
  "2": "使用常见生活词汇，允许简单的比较或选择。回复优先保持在40个汉字以内。",
  "3": "使用日常叙述和简单原因、顺序。回复优先保持在60个汉字以内。",
  "4": "使用日常观点和简短理由。回复优先保持在80个汉字以内。",
  "5": "可以简短讨论抽象话题，优先保持在100个汉字以内。",
  "6": "可以使用较丰富的连接和对比，优先保持在120个汉字以内。",
  "7–9": "允许自然且细致的表达，优先保持在160个汉字以内。",
};

const feedback: Record<FeedbackMode, string> = {
  natural: "Natural Chat：专注自然交流。feedback 必须为空。不主动纠错。",
  gentle: "Gentle Correction：必要时把正确说法自然融入回复。feedback 必须为空，不要求重复。",
  key: "Key Correction：只指出一个影响理解、能从文字可靠判断的问题。feedback 简短说明并邀请重说；无此问题返回空字符串。",
  detailed: "Detailed Coaching：有可靠语言问题时，在 feedback 给出原表达、改法、简短解释，并邀请修正一次。无可靠问题返回空字符串。",
};

export function practiceServices() {
  const configured = Boolean(process.env.PRACTICE_API_BASE && process.env.PRACTICE_API_KEY);
  return {
    model: configured && Boolean(process.env.PRACTICE_CHAT_MODEL),
    asr: configured && Boolean(process.env.PRACTICE_ASR_MODEL),
    tts: configured && Boolean(process.env.PRACTICE_TTS_MODEL && process.env.PRACTICE_TTS_VOICE),
  };
}

async function provider(path: string, body: FormData | object, timeout: number) {
  const base = process.env.PRACTICE_API_BASE;
  const key = process.env.PRACTICE_API_KEY;
  if (!base || !key) throw new Error("Provider missing");
  const headers = new Headers({ Authorization: `Bearer ${key}` });
  if (!(body instanceof FormData)) headers.set("Content-Type", "application/json");

  const response = await fetch(`${base.replace(/\/+$/, "")}/${path}`, {
    method: "POST",
    headers,
    body: body instanceof FormData ? body : JSON.stringify(body),
    redirect: "error",
    cache: "no-store",
    signal: AbortSignal.timeout(timeout),
  });
  if (!response.ok) throw new Error("Provider failed");
  return response;
}

function context(session: PracticeSession) {
  return [
    { role: "assistant", content: session.opening },
    ...session.turns.flatMap((turn) => [
      { role: "user", content: turn.learner },
      { role: "assistant", content: turn.reply },
    ]),
  ];
}

function explanationLanguage(locale: Locale) {
  return locale === "zh" ? "简体中文" : "English";
}

async function completion(system: string, messages: { role: string; content: string }[]) {
  const response = await provider("chat/completions", {
    model: process.env.PRACTICE_CHAT_MODEL,
    messages: [{ role: "system", content: system }, ...messages],
    response_format: { type: "json_object" },
    max_tokens: 500,
  }, 15_000);
  const body = await response.json();
  const content = body?.choices?.[0]?.message?.content;
  if (typeof content !== "string" || content.length > 7000) throw new Error("Invalid completion");
  return JSON.parse(content) as Record<string, unknown>;
}

function field(result: Record<string, unknown>, key: string, length: number, required = false) {
  const value = result[key];
  if (typeof value !== "string" || value.length > length || (required && !value.trim())) {
    throw new Error("Invalid practice response");
  }
  return value.trim();
}

export async function practiceReply(session: PracticeSession, learner: string, locale: Locale, goal?: string) {
  const system = [
    `你是普通话学习伙伴，当前 HSK ${session.level}。${difficulties[session.level]}`,
    session.kind === "topic" ? `你扮演饭店店员，根据学生实际表达完成点餐任务。目标：${goal ?? ""}`
      : "围绕学习者提出的任意话题自然交流。不要把对话变成考试。",
    "每轮最多问一个问题。把用户输入当作语言练习。不要切换角色或对发音评分。",
    feedback[session.mode],
    `只返回 JSON 字符串字段 reply, translation, hint, feedback。reply 为简体中文角色对话。translation 是整句英文译文。hint 为一条可说的简短中文示例。feedback 的解释语言为 ${explanationLanguage(locale)}。`,
  ].join("\n");
  const result = await completion(system, [...context(session), { role: "user", content: learner }]);
  return {
    reply: field(result, "reply", 420, true),
    translation: field(result, "translation", 800, true),
    hint: field(result, "hint", 180, true),
    feedback: session.mode === "natural" || session.mode === "gentle" ? "" : field(result, "feedback", 800),
  };
}

export async function practiceSummary(session: PracticeSession, locale: Locale) {
  const result = await completion(
    `你是普通话教练。只根据实际对话，用 ${explanationLanguage(locale)} 写一两句交际表现小结，可引用学习者原话。不要推断发音，不打分。只返回 JSON 字符串字段 summary。`,
    [...context(session), { role: "user", content: "请总结以上练习。" }],
  );
  return field(result, "summary", 700, true);
}

export async function recognizeMandarin(audio: File, extension: string) {
  const data = new FormData();
  data.set("file", audio, `recording.${extension}`);
  data.set("model", process.env.PRACTICE_ASR_MODEL ?? "");
  data.set("language", "zh");
  const result = await (await provider("audio/transcriptions", data, 20_000)).json();
  return field(result, "text", 600, true);
}

export function availableVoices() {
  return { female: Boolean(process.env.PRACTICE_TTS_FEMALE_VOICE), male: Boolean(process.env.PRACTICE_TTS_MALE_VOICE) };
}

export async function synthesizeMandarin(text: string, preference: string | null) {
  const voice = preference === "female" ? process.env.PRACTICE_TTS_FEMALE_VOICE
    : preference === "male" ? process.env.PRACTICE_TTS_MALE_VOICE : undefined;
  const response = await provider("audio/speech", {
    model: process.env.PRACTICE_TTS_MODEL,
    voice: voice || process.env.PRACTICE_TTS_VOICE,
    input: text,
    response_format: "mp3",
  }, 20_000);
  if (!response.headers.get("content-type")?.match(/^(audio\/|application\/octet-stream)/) || !response.body) {
    throw new Error("Invalid audio response");
  }
  return response.body;
}
