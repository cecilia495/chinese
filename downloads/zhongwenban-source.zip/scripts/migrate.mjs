import { readdir, readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import pg from "pg";

for (const file of [".env.local", ".env"]) {
  try {
    process.loadEnvFile(file);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
}

if (!process.env.DATABASE_URL) {
  console.error("Set DATABASE_URL before running migrations.");
  process.exit(1);
}

const database = new pg.Client({
  connectionString: process.env.DATABASE_URL,
  connectionTimeoutMillis: 5000,
});
const directory = new URL("../db/migrations/", import.meta.url);

async function migrate() {
  await database.connect();
  await database.query("BEGIN");
  // Serialize migration runs targeting the same database.
  await database.query("SELECT pg_advisory_xact_lock(214206719, 139204308)");
  await database.query(`
    CREATE TABLE IF NOT EXISTS app_schema_migrations (
      filename text PRIMARY KEY,
      checksum text NOT NULL,
      applied_at timestamptz NOT NULL DEFAULT now()
    )
  `);

  const { rows } = await database.query("SELECT filename, checksum FROM app_schema_migrations");
  const applied = new Map(rows.map(({ filename, checksum }) => [filename, checksum]));
  const pending = [];
  const files = (await readdir(directory)).filter((name) => /^\d+_.+\.sql$/.test(name)).sort();
  for (const filename of files) {
    const sql = await readFile(new URL(filename, directory), "utf8");
    const checksum = createHash("sha256").update(sql).digest("hex");
    if (applied.has(filename)) {
      if (applied.get(filename) !== checksum) throw new Error(`Applied migration changed: ${filename}`);
      continue;
    }

    await database.query(sql);
    await database.query("INSERT INTO app_schema_migrations (filename, checksum) VALUES ($1, $2)", [filename, checksum]);
    pending.push(filename);
  }

  await database.query("COMMIT");
  console.log(pending.length ? `Applied: ${pending.join(", ")}` : "No pending migrations.");
}

try {
  await migrate();
} catch (error) {
  // Closing the connection rolls back any uncommitted changes.
  console.error(error.message);
  process.exitCode = 1;
} finally {
  await database.end();
}
