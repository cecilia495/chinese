import { getDiningLesson } from "@/lib/dining";
import { isKind, isMode, isSessionId, maxLearnerText, maxPracticeTurns } from "@/lib/practice";
import { practiceReply, practiceServices, practiceSummary } from "@/lib/practice-provider";
import { authorizePractice, practiceFailure as fail, readPracticeJson } from "@/lib/practice-request";
import { discardUnsubmittedRecordings } from "@/lib/research";
import { consumeQuota, loadPractice, savePracticeChange, storeMode, storeTurn } from "@/lib/practice-store";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const access = await authorizePractice(request);
    if (access.error) return access.error;
    const { database, user, preferences } = access;
    const input = await readPracticeJson(request);
    if (!input) return fail(400);

    if (input.action === "start") {
      if (!practiceServices().model) return fail(503);
      if (!isKind(input.kind)) return fail(400);
      const lesson = getDiningLesson(preferences.level);
      if (input.kind === "topic" && !lesson) return fail(404);
      const opening = input.kind === "topic" && lesson ? lesson.scenario[0].prompt
        : preferences.level === "1" || preferences.level === "2" ? "你好！你想聊什么？" : "你好！今天想聊些什么？";
      const { rows } = await database.query<{ id: string }>(
        `INSERT INTO practice_sessions (user_id, kind, topic_id, hsk_level, interface_language, feedback_mode, opening, voice_id, speech_rate)
         SELECT user_id, $2, $3, $4, $5, default_feedback_mode, $6, voice_id, speech_rate
         FROM learner_profiles WHERE user_id = $1 RETURNING id`,
        [user.id, input.kind, input.kind === "topic" ? "dining" : null, preferences.level, preferences.locale, opening],
      );
      return Response.json({ session: await loadPractice(database, user.id, rows[0].id) });
    }

    if (!isSessionId(input.id)) return fail(400);
    const session = await loadPractice(database, user.id, input.id);
    if (!session) return fail(404);
    if (input.action === "load") return Response.json({ session });
    if (session.ended || input.revision !== session.revision) return fail(409);

    let saved: boolean;
    if (input.action === "mode") {
      const { mode } = input;
      if (!isMode(mode)) return fail(400);
      if (mode === session.mode) return Response.json({ session });
      saved = await savePracticeChange(database, user.id, session, (client) => storeMode(client, session, mode));
    } else if (input.action === "reply") {
      if (!practiceServices().model) return fail(503);
      const { learner } = input;
      if (typeof learner !== "string" || learner.length > maxLearnerText || !learner.trim()) return fail(400);
      if (session.turns.length >= maxPracticeTurns) return fail(409);
      if (!await consumeQuota(database, user.id, "model")) return fail(429);

      let reply;
      try {
        reply = await practiceReply(session, learner.trim(), preferences.locale, getDiningLesson(session.level)?.goal.zh);
      } catch {
        return fail(502);
      }
      const turn = { ...reply, learner: learner.trim(), position: session.turns.length + 1, mode: session.mode };
      const previous = session.turns.at(-1);
      const revisionOf = input.revisionReply === true && previous?.feedback ? previous.position : null;
      saved = await savePracticeChange(database, user.id, session, (client) =>
        storeTurn(client, session.id, turn, preferences.locale,
          isSessionId(input.transcriptionId) ? input.transcriptionId : null, revisionOf));
    } else if (input.action === "finish") {
      let summary: string | null = null;
      if (session.turns.length && input.withSummary === true) {
        if (!practiceServices().model) return fail(503);
        if (!await consumeQuota(database, user.id, "model")) return fail(429);
        try {
          summary = await practiceSummary(session, preferences.locale);
        } catch {
          return fail(502);
        }
      }
      saved = await savePracticeChange(database, user.id, session, async (client) => {
        await client.query("UPDATE practice_sessions SET ended_at = now(), summary = $2 WHERE id = $1", [session.id, summary]);
        await client.query("DELETE FROM practice_transcriptions WHERE session_id = $1", [session.id]);
      });
    } else {
      return fail(400);
    }

    if (!saved) return fail(409);
    if (input.action === "finish") {
      await discardUnsubmittedRecordings(database, user.id, session.id).catch(() => {
        // The consent page can retry deletion if storage was unavailable.
      });
    }
    return Response.json({ session: await loadPractice(database, user.id, session.id) });
  } catch {
    return fail(503);
  }
}
