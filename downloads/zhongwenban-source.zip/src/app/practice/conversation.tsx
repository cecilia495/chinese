"use client";

import Link from "next/link";
import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { PracticeCompletion } from "@/app/components/practice-completion";
import { LessonRecorder, type RecordingState } from "@/app/learn/lesson-audio";
import { diningCopy } from "@/lib/dining-i18n";
import { dictionaries, type Locale } from "@/lib/i18n";
import type { Level } from "@/lib/learner";
import { feedbackModes, maxLearnerText, maxPracticeTurns, type PracticeKind, type PracticeSession } from "@/lib/practice";
import { researchCopy } from "@/lib/research-i18n";
import { practiceCopy } from "@/lib/practice-i18n";
import { PartnerPresence, type PartnerActivity } from "./partner-presence";

type Props = {
  locale: Locale;
  viewerKey: string;
  level: Level;
  kind: PracticeKind;
  voice: { asr: boolean; tts: boolean };
  topic?: ReactNode;
};

class PracticeError extends Error {
  constructor(readonly status: number) {
    super("Practice request failed");
  }
}

async function requestPractice(input: object) {
  const response = await fetch("/api/practice", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  if (!response.ok) throw new PracticeError(response.status);
  return (await response.json() as { session: PracticeSession }).session;
}

function remember(key: string, value?: string) {
  try {
    if (value) sessionStorage.setItem(key, value);
    else sessionStorage.removeItem(key);
  } catch {
    // Practice remains usable if browser storage is disabled.
  }
}

function normalSpeed(session: PracticeSession) {
  return session.speechRate ?? (session.level === "1" || session.level === "2" ? .85 : 1);
}

export function Conversation({ locale, viewerKey, level, kind, voice, topic }: Props) {
  const t = practiceCopy[locale];
  const common = dictionaries[locale];
  const researchCopyForLocale = researchCopy[locale];
  const key = `practice:v1:${viewerKey}:${kind}:${level}`;
  const [session, setSession] = useState<PracticeSession>();
  const [resumeId, setResumeId] = useState<string>();
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [mic, setMic] = useState<RecordingState>("idle");
  const [error, setError] = useState("");
  const [draft, setDraft] = useState("");
  const [recording, setRecording] = useState<Blob>();
  const [researchStatus, setResearchStatus] = useState<"saved" | "failed" | "off">("off");
  const [revisionReply, setRevisionReply] = useState(false);
  const [transcriptionId, setTranscriptionId] = useState<string>();
  const [recognizing, setRecognizing] = useState(false);
  const [loadingAudio, setLoadingAudio] = useState(false);
  const [playback, setPlayback] = useState<"idle" | "buffering" | "speaking">("idle");
  const [hasAudio, setHasAudio] = useState(false);
  const [summaryError, setSummaryError] = useState(false);
  const [recordingKey, setRecordingKey] = useState(0);
  const transcript = useRef<HTMLOListElement>(null);
  const player = useRef<HTMLAudioElement>(null);
  const clips = useRef(new Map<string, Blob>());
  const audioRequest = useRef<AbortController | null>(null);
  const audioUrl = useRef<string | undefined>(undefined);
  const active = useRef(false);
  const operation = useRef(false);
  const canAutoplay = kind === "call";

  useEffect(() => {
    let cancelled = false;
    active.current = true;
    async function restore() {
      let id: string | null = null;
      try {
        id = sessionStorage.getItem(key);
        if (id) {
          const saved = await requestPractice({ action: "load", id });
          if (!cancelled) setSession(saved);
        }
      } catch (error) {
        if (error instanceof PracticeError && (error.status === 404 || error.status === 400)) {
          remember(key);
        } else if (id && !cancelled) {
          setResumeId(id);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    void restore();
    return () => {
      cancelled = true;
      active.current = false;
      audioRequest.current?.abort();
      if (audioUrl.current) URL.revokeObjectURL(audioUrl.current);
    };
  }, [key]);

  useEffect(() => {
    if (transcript.current) transcript.current.scrollTop = transcript.current.scrollHeight;
  }, [session?.turns.length]);

  function explain(error: unknown, speech = false) {
    if (error instanceof PracticeError && error.status === 429) return t.limited;
    if (error instanceof PracticeError && error.status === 401) return t.unavailable;
    return speech ? t.speechError : t.error;
  }

  async function playReply(id: string, position: number, rate: number, automatic = false) {
    if (!voice.tts || audioRequest.current) return;
    const controller = new AbortController();
    audioRequest.current = controller;
    player.current?.pause();
    setLoadingAudio(true);
    setError("");
    try {
      const clipKey = `${id}:${position}`;
      let clip = clips.current.get(clipKey);
      if (!clip) {
        const response = await fetch("/api/practice/speech", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id, position }),
          signal: controller.signal,
        });
        if (!response.ok) throw new PracticeError(response.status);
        clip = await response.blob();
        if (!clip.size) throw new Error("Empty speech");
        const oldest = clips.current.keys().next().value;
        if (clips.current.size >= 6 && oldest) clips.current.delete(oldest);
        clips.current.set(clipKey, clip);
      }
      const element = player.current;
      if (!element || controller.signal.aborted) return;
      if (audioUrl.current) URL.revokeObjectURL(audioUrl.current);
      audioUrl.current = URL.createObjectURL(clip);
      element.src = audioUrl.current;
      element.playbackRate = rate;
      element.preservesPitch = true;
      setHasAudio(true);
      await element.play().catch((error: unknown) => {
        const interrupted = error instanceof DOMException && (
          error.name === "AbortError" || (automatic && error.name === "NotAllowedError")
        );
        if (!interrupted) throw error;
      });
    } catch (error) {
      if (active.current && !controller.signal.aborted) setError(explain(error, true));
    } finally {
      if (audioRequest.current === controller) audioRequest.current = null;
      if (active.current && !controller.signal.aborted) setLoadingAudio(false);
    }
  }

  async function run(action: string, fields: Record<string, unknown> = {}) {
    if (operation.current) return;
    operation.current = true;
    setBusy(true);
    setThinking(action === "reply" || (action === "finish" && fields.withSummary === true && Boolean(session?.turns.length)));
    if (action === "reply" || action === "finish") player.current?.pause();
    setError("");
    try {
      const updated = await requestPractice({ action, id: session?.id, revision: session?.revision, ...fields });
      if (!active.current) return;
      setSession(updated);
      setResumeId(undefined);
      remember(key, updated.id);

      if (action === "start" || action === "reply") {
        setDraft("");
        setTranscriptionId(undefined);
        setResearchStatus("off");
        setRevisionReply(false);
        setRecording(undefined);
        setRecordingKey((count) => count + 1);
        if (canAutoplay) void playReply(updated.id, updated.turns.length, normalSpeed(updated), true);
      }
      if (action === "finish") {
        setSummaryError(false);
        requestAnimationFrame(() => document.getElementById("lesson-current-step")?.focus());
      }
    } catch (error) {
      if (!active.current) return;
      if (session && error instanceof PracticeError && error.status === 409) {
        try {
          setSession(await requestPractice({ action: "load", id: session.id }));
          setError(t.conflict);
          return;
        } catch {
          // Use the common request error if refresh fails.
        }
      }
      if (action === "load" && error instanceof PracticeError && error.status === 404) {
        remember(key);
        setResumeId(undefined);
      }
      if (action === "finish") setSummaryError(true);
      setError(explain(error));
    } finally {
      operation.current = false;
      if (active.current) {
        setBusy(false);
        setThinking(false);
      }
    }
  }

  async function transcribe() {
    if (!session || !recording || operation.current) return;
    operation.current = true;
    player.current?.pause();
    setRecognizing(true);
    setError("");
    try {
      const form = new FormData();
      form.set("id", session.id);
      form.set("audio", recording);
      const response = await fetch("/api/practice/speech", { method: "POST", body: form });
      if (!response.ok) throw new PracticeError(response.status);
      const { text, transcriptionId, research } = await response.json() as {
        text: string; transcriptionId: string; research: "saved" | "failed" | "off";
      };
      if (active.current) {
        setDraft(text);
        setTranscriptionId(transcriptionId);
        setResearchStatus(research);
        setRecording(undefined);
      }
    } catch (error) {
      if (active.current) setError(explain(error, true));
    } finally {
      operation.current = false;
      if (active.current) setRecognizing(false);
    }
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (draft.trim()) void run("reply", { learner: draft.trim(), transcriptionId, revisionReply });
  }

  const controlsBusy = busy || recognizing || loadingAudio;
  const unavailable = controlsBusy || mic !== "idle";
  const showPartner = kind !== "topic";
  let activity: PartnerActivity = "ready";
  if (mic === "recording") activity = "listening";
  else if (mic === "requesting") activity = "permission";
  else if (recognizing) activity = "recognizing";
  else if (thinking) activity = "thinking";
  else if (playback === "speaking") activity = "speaking";
  else if (loadingAudio || playback === "buffering") activity = "buffering";

  const audio = (
    <audio ref={player} controls={!unavailable} hidden={!hasAudio} aria-label={t.play}
      onPlaying={(event) => { if (!event.currentTarget.paused) setPlayback("speaking"); }}
      onWaiting={(event) => { if (!event.currentTarget.paused) setPlayback("buffering"); }}
      onPause={() => setPlayback("idle")} onEnded={() => setPlayback("idle")}
      onEmptied={() => setPlayback("idle")} onError={() => { setPlayback("idle"); setError(t.speechError); }} />
  );
  const role = kind === "topic" ? t.waiter : t.partner;
  const turnLimit = (session?.turns.length ?? 0) >= maxPracticeTurns;
  if (!session) {
    return (
      <section className="panel practice-panel">
        {showPartner && <PartnerPresence locale={locale} activity={activity} />}
        {topic}
        <p>{t.disclosure} <Link href="/research" className="back">{researchCopyForLocale.consent}</Link></p>
        {canAutoplay && <p>{t.callDescription}</p>}
        {!voice.asr && !voice.tts && <p className="status">{t.noVoice}</p>}
        {error && <p className="form-error" role="alert">{error}</p>}
        {resumeId && !error && <p className="form-error" role="alert">{t.error}</p>}
        <button type="button" className="button" disabled={busy || loading}
          onClick={() => resumeId ? run("load", { id: resumeId }) : run("start", { kind })}>
          {busy || loading ? t.working : resumeId ? t.resume : t.start}
        </button>
        {audio}
      </section>
    );
  }

  if (session.ended) {
    return (
      <PracticeCompletion title={t.finished} home={common.back} actions={<>
        <button type="button" className="lesson-secondary" onClick={() => {
          remember(key);
          clips.current.clear();
          if (audioUrl.current) URL.revokeObjectURL(audioUrl.current);
          audioUrl.current = undefined;
          setSession(undefined);
          setHasAudio(false);
          setPlayback("idle");
          setError("");
        }}>{t.again}</button>
        <Link className="lesson-secondary" href={kind === "topic" ? "/talk" : "/topics"}>
          {kind === "topic" ? common.modes.talk.title : common.modes.topics.title}
        </Link>
      </>}>
        <p>{session.summary ?? t.emptySummary}</p>
      </PracticeCompletion>
    );
  }

  function playButtons(session: PracticeSession, position: number) {
    return voice.tts && (
      <div className="lesson-actions">
        <button type="button" className="lesson-secondary" disabled={unavailable} onClick={() => playReply(session.id, position, normalSpeed(session))}>{t.play}</button>
        <button type="button" className="lesson-secondary" disabled={unavailable} onClick={() => playReply(session.id, position, Math.min(.85, normalSpeed(session) * .85))}>{t.slow}</button>
      </div>
    );
  }

  return (
    <section className={`panel practice-panel${showPartner ? " practice-with-partner" : ""}`}>
      {showPartner && <PartnerPresence locale={locale} activity={activity}
        pause={playback !== "idle" ? () => player.current?.pause() : undefined} />}
      <div className="practice-session-options">
        <p className="status">HSK {session.level}</p>
        <label className="practice-mode">
          {t.feedbackMode}
          <select value={session.mode} disabled={unavailable} onChange={(event) => run("mode", { mode: event.target.value })}>
            {feedbackModes.map((mode) => <option key={mode} value={mode}>{t.modes[mode]}</option>)}
          </select>
        </label>
      </div>
      <ol className="practice-transcript" aria-live="polite" ref={transcript}>
        <li>
          <strong>{role}</strong>
          <p lang="zh-Hans">{session.opening}</p>
          {playButtons(session, 0)}
        </li>
        {session.turns.map((turn) => (
          <li key={turn.position}>
            <strong>{t.you}</strong>
            <p lang="zh-Hans">{turn.learner}</p>
            <strong>{role}</strong>
            <p lang="zh-Hans">{turn.reply}</p>
            {turn.feedback && <p><strong>{t.feedback}</strong> {turn.feedback}</p>}
            {locale === "en" && <details><summary>{t.translation}</summary><p>{turn.translation}</p></details>}
            <details><summary>{t.hint}</summary><p lang="zh-Hans">{turn.hint}</p></details>
            {playButtons(session, turn.position)}
          </li>
        ))}
      </ol>
      {audio}

      {voice.asr && !turnLimit ? (
        <fieldset disabled={controlsBusy} className="practice-record">
          <LessonRecorder key={recordingKey} t={diningCopy[locale]} onRecordingStart={() => {
            player.current?.pause();
            setRecording(undefined);
          }} onRecorded={setRecording} onStateChange={setMic}
            extraAction={recording && <button type="button" className="lesson-secondary" onClick={transcribe}>{t.transcribe}</button>} />
        </fieldset>
      ) : !voice.asr && <p className="status">{t.noRecognition}</p>}
      {!voice.tts && <p className="status">{t.noPlayback}</p>}
      {transcriptionId && <p role="status">{t.transcriptReady}</p>}
      {researchStatus !== "off" && <p role="status">{researchCopyForLocale[researchStatus]}</p>}
      {!showPartner && recognizing && <p role="status">{t.listening}</p>}
      {turnLimit ? <p>{t.max}</p> : (
        <form method="post" className="preferences lesson-reply" onSubmit={submit}>
          <label htmlFor="practice-message">{t.message}</label>
          <textarea id="practice-message" lang="zh-Hans" value={draft} onChange={(event) => {
            setDraft(event.target.value);
            if (!event.target.value.trim()) setTranscriptionId(undefined);
          }} maxLength={maxLearnerText} required rows={2} disabled={unavailable} />
          {session.turns.at(-1)?.feedback && <label className="lesson-check">
            <input type="checkbox" checked={revisionReply} disabled={unavailable}
              onChange={(event) => setRevisionReply(event.target.checked)} />{researchCopyForLocale.revision}
          </label>}
          <button type="submit" className="button" disabled={!draft.trim() || unavailable}>{busy ? t.working : t.send}</button>
        </form>
      )}

      {error && <p className="form-error" role="alert">{error}</p>}
      <div className="lesson-actions">
        <button type="button" className="lesson-secondary" disabled={unavailable} onClick={() => run("finish", { withSummary: true })}>{t.finish}</button>
        {summaryError && <button type="button" className="lesson-secondary" disabled={unavailable} onClick={() => run("finish", { withSummary: false })}>{t.finishWithout}</button>}
      </div>
    </section>
  );
}
