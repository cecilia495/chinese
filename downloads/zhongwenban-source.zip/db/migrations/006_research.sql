ALTER TABLE learner_profiles ADD COLUMN student_id uuid NOT NULL DEFAULT gen_random_uuid() UNIQUE;
ALTER TABLE practice_turns ADD COLUMN revision_of integer;
ALTER TABLE practice_turns ADD CONSTRAINT practice_turn_revision_fk
  FOREIGN KEY (session_id, revision_of) REFERENCES practice_turns(session_id, position);

CREATE TABLE teacher_roles (
  user_id text PRIMARY KEY REFERENCES "user"(id) ON DELETE CASCADE
);
CREATE TABLE teacher_students (
  teacher_id text REFERENCES teacher_roles(user_id) ON DELETE CASCADE,
  learner_id text REFERENCES learner_profiles(user_id) ON DELETE CASCADE,
  PRIMARY KEY (teacher_id, learner_id)
);
CREATE TABLE research_consents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL REFERENCES learner_profiles(user_id),
  policy_version integer NOT NULL,
  granted_at timestamptz NOT NULL DEFAULT now(),
  revoked_at timestamptz
);
CREATE UNIQUE INDEX research_active_consent_idx ON research_consents (user_id) WHERE revoked_at IS NULL;

CREATE TABLE research_recordings (
  id uuid PRIMARY KEY,
  recording_id uuid NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  consent_id uuid NOT NULL REFERENCES research_consents(id),
  session_id uuid NOT NULL REFERENCES practice_sessions(id),
  turn_position integer,
  object_key text NOT NULL UNIQUE,
  mime_type text NOT NULL,
  size_bytes integer NOT NULL CHECK (size_bytes > 0),
  sha256 text NOT NULL,
  original_asr text NOT NULL,
  stored boolean NOT NULL DEFAULT false,
  captured_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (session_id, turn_position),
  FOREIGN KEY (session_id, turn_position) REFERENCES practice_turns(session_id, position)
);
-- Recordings outlive short-lived transcription receipts once a turn is submitted.
CREATE INDEX research_recordings_consent_idx ON research_recordings (consent_id);
