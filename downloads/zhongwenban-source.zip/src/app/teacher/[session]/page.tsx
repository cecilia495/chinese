import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { getViewer } from "@/lib/preferences";
import { isMode, isSessionId } from "@/lib/practice";
import { practiceCopy } from "@/lib/practice-i18n";
import { teacherAccess, teacherEvents, teacherQuery, teacherSessions, teacherTurns } from "@/lib/teacher";
import { teacherCopy } from "@/lib/teacher-i18n";

export default async function TeacherSessionPage({ params }: { params: Promise<{ session: string }> }) {
  const access = await teacherAccess();
  if (access.status !== 200) redirect("/teacher");
  const { session: id } = await params;
  if (!isSessionId(id)) notFound();
  const [session] = await teacherSessions(access.database, access.teacherId, { session: id });
  if (!session) notFound();

  const [turns, events, viewer] = await Promise.all([
    teacherTurns(access.database, access.teacherId, id), teacherEvents(access.database, access.teacherId, id), getViewer(),
  ]);
  const { locale } = viewer.preferences;
  const t = teacherCopy[locale];
  const modes = practiceCopy[locale].modes;
  const mode = (value: string) => isMode(value) ? modes[value] : value;
  const date = new Intl.DateTimeFormat(locale, { dateStyle: "medium", timeStyle: "short", timeZone: "UTC" });

  return <section className="subpage teacher">
    <Link className="back" href="/teacher">{t.back}</Link>
    <h1>{t.detail}</h1>
    <div className="panel">
      <p>{t.student} · {session.student_id}</p>
      <p>HSK {session.hsk_level} · {session.interface_language} · {t.kinds[session.kind as keyof typeof t.kinds]}</p>
      <p>{t.topic} · {session.topic_id ?? t.noTopic}{session.scenario_id && ` · ${t.scenario} ${session.scenario_id}`}</p>
      <p>{t.started} · {date.format(session.started_at)}{session.ended_at && ` · ${t.ended} ${date.format(session.ended_at)}`}</p>
      <p><strong>{t.opening}</strong> <span lang="zh-Hans">{session.opening}</span></p>
      {session.summary && <p><strong>{t.summary}</strong> {session.summary}</p>}
      <div className="lesson-actions">
        {Object.entries({ csv: "CSV", xlsx: "Excel", json: "JSON", audio: t.audioZip }).map(([format, label]) =>
          <a className="lesson-secondary" key={format} href={`/api/teacher/export?${teacherQuery({ session: id }, { format })}`}>{label}</a>)}
      </div>
    </div>
    <section className="panel teacher-section">
      <h2>{t.turns} · {turns.length}</h2>
      {turns.length ? <ol className="learning-list">{turns.map((turn) => (
        <li className="practice-turn-review" key={turn.position}>
          <p className="status">{turn.position} · {date.format(turn.created_at)} · {mode(turn.feedback_mode)}
            {turn.revision_of && ` · ${t.revised} ${turn.revision_of}`}</p>
          {turn.original_asr && <p><strong>{t.original}</strong> <span lang="zh-Hans">{turn.original_asr}</span></p>}
          <p><strong>{t.learner}</strong> <span lang="zh-Hans">{turn.learner_text}</span></p>
          <p><strong>{t.assistant}</strong> <span lang="zh-Hans">{turn.assistant_text}</span></p>
          {turn.hint && <p><strong>{t.hint}</strong> <span lang="zh-Hans">{turn.hint}</span></p>}
          {turn.feedback && <p><strong>{t.feedback}</strong> {turn.feedback}</p>}
          {turn.recording_id && <div className="teacher-recording">
            <audio controls preload="none" aria-label={t.recording} src={`/api/teacher/audio/${turn.recording_id}`} />
            <a href={`/api/teacher/audio/${turn.recording_id}`} download>{t.download}</a>
          </div>}
        </li>
      ))}</ol> : <p>{t.none}</p>}
    </section>
    <section className="panel teacher-section">
      <h2>{t.changes}</h2>
      {events.length ? <ul>{events.map((event) => (
        <li key={event.id}>{date.format(event.created_at)} · {mode(event.previous_mode)} → {mode(event.next_mode)}</li>
      ))}</ul> : <p>{t.none}</p>}
    </section>
  </section>;
}
