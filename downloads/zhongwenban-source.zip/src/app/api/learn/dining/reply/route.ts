import { getDatabase } from "@/lib/db";
import { getDiningLesson } from "@/lib/dining";
import { diningModelConfigured, parseDiningRequest, requestDiningReply } from "@/lib/dining-model";
import { getViewer } from "@/lib/preferences";

export const runtime = "nodejs";

function failure(status: number) {
  return Response.json({ ok: false }, { status });
}

export async function POST(request: Request) {
  const database = getDatabase();
  const canonicalUrl = process.env.BETTER_AUTH_URL;
  if (!database || !canonicalUrl || !diningModelConfigured()) return failure(503);

  try {
    if (request.headers.get("origin") !== new URL(canonicalUrl).origin) return failure(403);
    const { user, needsSetup, preferences } = await getViewer();
    if (!user || needsSetup) return failure(401);
    const lesson = getDiningLesson(preferences.level);
    if (!lesson) return failure(404);

    if (Number(request.headers.get("content-length")) > 4096) return failure(413);
    const json = await request.json().catch(() => null);
    const practice = parseDiningRequest(json);
    if (!practice) return failure(400);

    const quota = await database.query(
      `INSERT INTO dining_practice_quota (user_id) VALUES ($1)
       ON CONFLICT (user_id) DO UPDATE
       SET requests = CASE WHEN dining_practice_quota.window_start <= now() - interval '5 minutes'
                           THEN 1 ELSE dining_practice_quota.requests + 1 END,
           window_start = CASE WHEN dining_practice_quota.window_start <= now() - interval '5 minutes'
                               THEN now() ELSE dining_practice_quota.window_start END
       WHERE dining_practice_quota.requests < 8 OR dining_practice_quota.window_start <= now() - interval '5 minutes'
       RETURNING requests`,
      [user.id],
    );
    if (!quota.rows.length) return failure(429);

    try {
      const reply = await requestDiningReply(lesson, practice);
      return Response.json({ reply });
    } catch {
      return failure(502);
    }
  } catch {
    return failure(503);
  }
}
