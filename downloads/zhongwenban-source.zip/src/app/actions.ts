"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { getDatabase } from "@/lib/db";
import { isLevel, isLocale } from "@/lib/learner";
import { isMode, isSpeechRate, isVoiceChoice } from "@/lib/practice";
import { getViewer } from "@/lib/preferences";

export async function savePreferences(form: FormData) {
  const locale = form.get("locale");
  const level = form.get("level");
  const mode = form.get("feedback-mode");
  const rate = form.get("speech-rate");
  const voice = form.get("voice");
  if (!isLocale(locale) || !isLevel(level) || (mode !== null && !isMode(mode)) ||
      (rate !== null && !isSpeechRate(rate)) || (voice !== null && !isVoiceChoice(voice))) {
    redirect("/settings?error=invalid");
  }

  try {
    const { user } = await getViewer();
    if (user) {
      const database = getDatabase();
      if (!database) throw new Error("PostgreSQL is unavailable");
      await database.query(
        `INSERT INTO learner_profiles (user_id, interface_language, hsk_level, default_feedback_mode, speech_rate, voice_id)
         VALUES ($1, $2, $3, COALESCE($4, 'gentle'), NULLIF($5, 'auto')::numeric, $6)
         ON CONFLICT (user_id) DO UPDATE
         SET interface_language = EXCLUDED.interface_language, hsk_level = EXCLUDED.hsk_level,
             default_feedback_mode = COALESCE($4, learner_profiles.default_feedback_mode),
             speech_rate = CASE WHEN $5::text IS NULL THEN learner_profiles.speech_rate ELSE EXCLUDED.speech_rate END,
             voice_id = COALESCE($6, learner_profiles.voice_id), updated_at = now()`,
        [user.id, locale, level, mode, rate, voice],
      );
    } else {
      const jar = await cookies();
      const options = { httpOnly: true, sameSite: "lax" as const, secure: process.env.BETTER_AUTH_URL?.startsWith("https://") ?? false, path: "/", maxAge: 60 * 60 * 24 * 365 };
      jar.set("zhb_locale", locale, options);
      jar.set("zhb_hsk", level, options);
    }
  } catch {
    redirect("/settings?error=save");
  }

  redirect("/");
}
