# 中文伴 · Speak Chinese with AI

面向成人学习者的独立普通话学习网站。当前完成阶段 8 的本地上线准备。网站提供 HSK 1–3 餐厅课程、AI 对话、个人生词库、学习进度及按分配权限开放的教师后台。

## 访客模式

需要 Node.js 22 或更新的受支持版本与 npm。

```bash
npm ci
npm run dev
```

访问 http://localhost:3000。访客默认以 English / HSK 2 打开首页。可在顶部更改等级和界面语言，设置保存在当前浏览器。

## 启用账户

准备一个可连接的 PostgreSQL 数据库。首次部署需要使用有权限建表和建索引的数据库用户运行迁移。

```bash
cp .env.example .env.local
openssl rand -base64 32
```

将生成值填入 `.env.local` 的 `BETTER_AUTH_SECRET`，填写 `DATABASE_URL`。本地可使用模板提供的 `BETTER_AUTH_URL=http://localhost:3000`。部署时将其设置为浏览器实际访问的 HTTPS URL。

```bash
npm run db:migrate
npm run dev
```

从首页底部进入「登录」，可通过邮箱和密码注册或登录。首次登录选择界面语言和 HSK 等级后进入首页。后续可进入「设置」修改，两项偏好随账户保存在 PostgreSQL 中。「账户」页允许退出。认证由 Better Auth 处理，档案写入使用已验证会话的用户 ID。

阶段 2 的邮箱密码账户供本地及受控试用。邮箱所有权验证、邮件与密码找回流程尚未接入。应用的基础认证请求限流由 Better Auth 持久保存在 PostgreSQL 中。用反向代理接入实际流量时，在代理处限制认证流量。

## 餐厅主题四步课程

从首页进入「逐步学习」（`/learn`）。HSK 1 练习点主食和茶，HSK 2 练习询问一道菜和做选择，HSK 3 练习看菜单并确认总价。课程包含词汇配图和例句、带字幕及译文的听力题、跟读录音回放和点餐互动。可跳过某一步，课程结束页会显示实际完成数。切换界面语言后，同一账户或访客的同等级课程状态可在当前标签页恢复。

普通话示范音频随项目提供，可慢速播放，无需运行时语音服务。跟读及口头作答使用浏览器录音，麦克风需要 HTTPS 或 localhost 和浏览器授权。录音只留在当前页面内存，离开对应步骤或重新录制时回收。听力题根据选择判断；口头作答和跟读可以自行回放对照。登录后可保存课程完成记录和收藏词语。

默认的引导式点餐可以用不同回答改变店员回复，访客也可使用。要启用额外的 AI 角色练习，先启用账户并运行迁移，再配置下列变量。

| 变量 | 值 |
| --- | --- |
| `DINING_MODEL_URL` | 完整的 OpenAI 兼容 Chat Completions 地址 |
| `DINING_MODEL_KEY` | 模型服务密钥 |
| `DINING_MODEL_NAME` | 实际部署的模型名 |

AI 模式向配置的服务发送学习者键入的文本和当次对话上下文，上下文中的 HSK 等级来自服务器档案。应用限制单次输入长度、上游超时和每个账户的短时请求量。这两轮课程内 AI 对话的正文留在当前标签页，模型调用计数和课程完成记录分别保存。

## 话题对话和自由交流

在「话题对话」中，HSK 1–3 可按当前等级直接练习点餐。在「自由交流」中，所有 HSK 等级可以自由选择话题，使用语音聊天或电话式练习。电话式练习采用轮流交流，浏览器允许时会自动播放 AI 回复。麦克风录音需要 HTTPS 或 localhost。学习者可以先核对和编辑普通话转录，再发送给模型。

先启用账户并运行 `npm run db:migrate`，然后在 `.env.local` 中按服务商文档配置以下变量并重启应用。

| 变量 | 用途 |
| --- | --- |
| `PRACTICE_API_BASE`、`PRACTICE_API_KEY` | OpenAI 兼容 API 根地址（含 `/v1`）与密钥 |
| `PRACTICE_CHAT_MODEL` | 支持 `chat/completions` 和 JSON Object 响应格式的对话模型 |
| `PRACTICE_ASR_MODEL` | 可选的普通话识别模型，支持 `audio/transcriptions` |
| `PRACTICE_TTS_MODEL`、`PRACTICE_TTS_VOICE` | 可选的语音模型和默认音色，支持 `audio/speech` 的 MP3 响应 |
| `PRACTICE_TTS_FEMALE_VOICE`、`PRACTICE_TTS_MALE_VOICE` | 可选的已试听普通话音色。配置后出现在账户设置中 |

交互提供提示、英文译文、回放、慢速播放和四种纠错方式。设置页可更改新会话默认的纠错方式、音色和播放速度。未手动选择语速时，HSK 1–2 用 0.85×，其他等级用 1.00×。会话创建时保留等级、音色、语速与配置版本。在会话内切换纠错方式会写入事件，并作用于下一轮模型请求。

应用保存实际发送的消息、AI 回复、实际反馈、纠错方式切换及会话小结。网页在当前标签页按等级和练习方式记住会话入口。刷新或切换界面语言可加载原对话，切回之前的等级时也可继续原会话。只有学习者点击「转录录音」才会把录音发送给语音服务。打开研究授权后，原始文件另存到私有对象存储，详见下文。未配置语音服务时可以文字对话。未配置模型时餐厅四步课程和引导式点餐仍可使用。

每次会话最多 24 个学习者话轮。服务端设置账户级模型和语音配额、上传大小限制和上游超时。小结失败时可以重试，或在完成页保留实际会话记录。

## 我的生词和学习进度

账户开启并应用全部数据库迁移后，已登录的学习者可以在课程词卡中收藏词语。「我的生词」按账户跨设备同步，保存收藏时的汉字、拼音、中英文释义、原始例句与课程来源，也可播放普通话例句并取消收藏。每个词语只保留一条收藏。

可从「复习到期词卡」开始简单复习。选择「记住了」后一天再次到期，选择「稍后再练」后十分钟再次到期。系统保存实际复习操作和下次到期时间。

餐厅课程结束后自动保存已完成步骤。离开前可查看保存状态，失败时可直接重试。「学习进度」显示完整完成的课程主题、实际保存的课程练习、结束的有效对话、已收藏与待复习词汇，以及最近一次真实反馈。对话时长用会话开始与结束时间计算，包含停顿。口语练习计数包含录音完成的跟读和含转录回复的已结束对话。旧对话仍计入对话总数，缺少转录标记的旧数据不计入口语次数。未授予研究录音权限时，站点只保存转录状态及最终发送的内容。

生词库与课程进度仅依赖 PostgreSQL。只有使用 AI 对话或在线语音时才需要模型和语音服务。访客可以继续练习餐厅课程，课程小结保留在当前标签页。

## 教师后台和研究录音

先启用账户并运行 `npm run db:migrate`。教师使用 Better Auth 账户登录 `/teacher`。管理员核验教师账户归属后，在有数据库权限的环境中授予教师角色，再分配已完成初次设置的学生。

```bash
npm run teacher:access -- grant teacher@example.test
npm run teacher:access -- assign teacher@example.test learner@example.test
```

用 `unassign` 撤销单个学生的分配，或用 `revoke` 撤销教师权限及其分配。教师端只展示被分配的学生，使用不含姓名和邮箱的稳定匿名 ID。已提交的实际对话文本可能由学生自行填写个人信息。导出文件按研究数据处理。列表可按学生、HSK、练习方式及 UTC 日期筛选，支持逐轮查看、筛选导出 CSV / Excel / JSON 和授权录音 ZIP。单次导出最多 5,000 行或 10 段录音，原始文件也可在会话详情中单独播放、下载。

学生在「设置 → 研究录音授权」单独选择是否留存原始录音。关闭该选项时，转录仍可用于当前学习。选项开启后，从授权生效起录音与原始转录会按本次上传处理，原始文件仅保存在私有对象存储。录音随转录凭据关联至实际发送的话轮。未提交的录音不会出现在教师后台，正常结束会话时会清理这类录音。教师端逐次核验分配和有效授权，撤回后禁止后续访问。应用会在撤回时删除已留存的原始文件及原始转录记录，失败或有多批文件时可继续重试。已发出的学习对话和之前已下载的文件由各自的数据流程管理。

启用录音保存需要配置 S3 或兼容存储：

- `RESEARCH_S3_BUCKET`、`RESEARCH_S3_REGION`。请创建专用私有桶，关闭公共访问与对象版本控制，确保应用删除对象时不会留下旧版本。
- 兼容存储可设置 `RESEARCH_S3_ENDPOINT` 和 `RESEARCH_S3_PATH_STYLE=true`。AWS 可以使用常规 IAM 身份；兼容存储可使用环境变量中的访问密钥。
- 应用身份需要在该桶的 `research/` 前缀读、写、删对象。录音不会写入 Web 公共目录，教师端通过本站鉴权接口播放。

## AI 伙伴与移动端

「自由交流」的语音聊天和电话式练习共用一张为项目生成的约 11 KB 的 WebP 伙伴插图。界面显示等待麦克风授权、正在听、正在转录、正在思考、正在准备语音、正在说话等状态。录音状态由 MediaRecorder 事件触发，转录、模型等待和语音准备跟随实际网络请求，播放状态跟随浏览器音频事件。播放暂停、结束或失败后相应恢复。电话自动播放被浏览器限制时，可手动播放。移动端保留紧凑的伙伴状态区、可滚动对话和就近的录音与转录操作。

## 构建、检查与运行

独立部署、上线验收及数据库和录音恢复流程见 [部署与恢复手册](docs/deployment.md)。

```bash
npm run lint
npm run build
npm run typecheck
npm start
```

应用采用 Next.js App Router、React、TypeScript、原生 CSS 和标准 PostgreSQL 客户端 `pg`，以单一 Node.js 应用运行。访问 `/api/health` 检查数据库连接。

| 数据库状态 | HTTP | 响应字段 |
| --- | --- | --- |
| 连接未配置 | 200 | `not_configured` |
| 实际执行 `SELECT 1` 成功 | 200 | `ok` |
| 连接或查询失败 | 503 | `unavailable` |

## 文件结构

| 路径 | 用途 |
| --- | --- |
| `src/app/layout.tsx`、`page.tsx`、`globals.css` | 页面外壳、响应式首页和统一样式 |
| `src/app/settings/`、`src/app/vocabulary/`、`src/app/progress/` | 账户偏好、个人生词与学习进度页面 |
| `src/app/account/`、`src/app/api/auth/`、`src/lib/auth.ts` | 中英文账户页与 Better Auth 路由 |
| `src/app/actions.ts`、`src/lib/preferences.ts` | 校验和读写当前会话的学习者偏好 |
| `src/lib/i18n.ts`、`src/lib/learner.ts` | 中英界面字典、共享等级和语言类型 |
| `src/app/api/health/route.ts`、`src/lib/db.ts` | PostgreSQL 连接池与健康检查 |
| `db/migrations/`、`scripts/migrate.mjs` | 版本化建表、迁移校验与执行 |
| `src/app/learn/`、`src/lib/dining.ts`、`src/lib/dining-i18n.ts` | 餐厅四步课程、媒体控件、三档原创教学内容与中英文案 |
| `src/app/api/learn/dining/reply/`、`src/lib/dining-model.ts` | 经账户验证的可选模型接口 |
| `src/app/topics/`、`src/app/talk/`、`src/app/practice/` | 餐厅话题、自由交流、电话式练习和统一对话界面 |
| `src/app/api/practice/`、`src/lib/practice-provider.ts`、`src/lib/practice-store.ts` | 会话、话轮、纠错事件和可替换模型与语音接口 |
| `src/app/api/learning/`、`src/lib/learning-store.ts` | 收藏、复习调度、课程保存及进度查询 |
| `src/app/teacher/`、`src/app/api/teacher/` | 教师工作台、范围鉴权、原始录音播放与下载 |
| `src/app/research/`、`src/lib/research.ts`、`src/lib/research-storage.ts` | 授权、原始录音和私有对象存储 |
| `src/app/practice/partner-presence.tsx`、`public/images/partner/` | 自由交流伙伴形象和事件驱动状态显示 |
| `src/app/components/practice-completion.tsx` | 三个学习入口共享的完成组件 |
| `public/images/dining/`、`public/audio/dining/` | 课程配图、普通话示范 MP3 和音色来源的许可文件 |
| `public/images/` | 三张为本项目生成的首页照片风格配图 |

## 课程来源与当前范围

- 原创任务参照用户提供的《新版 HSK 考试大纲》任务部分。对应 PDF 物理页码 8（一级「问答中国传统饮食」）、10–11（二级「问答日常饮食」）、14–15（三级「交流饮食情况」）。学习例句和对话是原创练习，等级取自教学目标和选用词汇。
- 正式目标词按大纲词汇表编号核对。一级为茶（17）、米饭（125）、面条儿（127），二级为还是（352）、鱼（483），三级为菜单（545）、碗（869）、一共（923）。
- 课程图片从用户提供的旧 Coze 备份 `public/images/dining/` 选取并压缩为 WebP。示范音频离线使用 MeloTTS Chinese/English 的普通话合成音色生成，来源及 MIT 许可见 `public/audio/dining/MELOTTS-LICENSE.txt`。音频供示范使用，专业语音质量审核与男女音色选择留待语音阶段。
- 三份 HSK 1–3 教材超过当前环境 32 MiB 文件传输上限。本阶段的词汇映射以已读取的大纲为依据。
- HSK 4–9 课程及专项话题暂未开放，自由交流支持所有等级。阶段 4 验证使用临时 PostgreSQL、测试模型服务与浏览器测试音源。真实供应商、实体麦克风及正式音色试听需在部署配置后验收。生产发布在真实域名和实际服务完成验收后进行。旧平台历史数据、教材文件和语音样本留在原附件中。
