import { createHash } from "node:crypto";
import { readdir, readFile } from "node:fs/promises";
import pg from "pg";
import { loadOperationsEnv } from "./operations-env.mjs";

loadOperationsEnv();
const production = process.argv.includes("--production");
const env = process.env;
const errors = [];
const url = (name, protocols) => {
  if (!env[name]) return;
  try {
    const parsed = new URL(env[name]);
    if (!protocols.includes(parsed.protocol) || !parsed.hostname) throw new Error();
    return parsed;
  } catch {
    errors.push(`${name} is not a valid ${protocols.join("/")} URL.`);
  }
};
const requireAll = (names) => {
  const missing = names.filter((name) => !env[name]);
  if (missing.length && missing.length < names.length) errors.push(`Incomplete configuration: ${missing.join(", ")}.`);
};

const databaseUrl = url("DATABASE_URL", ["postgres:", "postgresql:"]);
const authUrl = url("BETTER_AUTH_URL", production && env.BETTER_AUTH_SECRET ? ["https:"] : ["http:", "https:"]);
if (env.BETTER_AUTH_SECRET) {
  if (!databaseUrl || !authUrl) errors.push("Accounts require DATABASE_URL and BETTER_AUTH_URL.");
  if (env.BETTER_AUTH_SECRET.length < 32) errors.push("BETTER_AUTH_SECRET must be at least 32 characters.");
  if (authUrl && (authUrl.username || authUrl.password || authUrl.pathname !== "/" || authUrl.search || authUrl.hash)) {
    errors.push("BETTER_AUTH_URL must be the site origin.");
  }
}
if (production && databaseUrl && !env.BETTER_AUTH_SECRET) {
  console.log("Accounts are disabled.");
}
requireAll(["DINING_MODEL_URL", "DINING_MODEL_KEY", "DINING_MODEL_NAME"]);
if (["PRACTICE_ASR_MODEL", "PRACTICE_TTS_MODEL", "PRACTICE_TTS_VOICE", "PRACTICE_CHAT_MODEL", "PRACTICE_API_KEY", "PRACTICE_API_BASE"]
  .some((name) => env[name]) && (!env.PRACTICE_CHAT_MODEL || !env.PRACTICE_API_KEY || !env.PRACTICE_API_BASE)) {
  errors.push("Conversation requires PRACTICE_API_BASE, PRACTICE_API_KEY and PRACTICE_CHAT_MODEL.");
}
requireAll(["PRACTICE_TTS_MODEL", "PRACTICE_TTS_VOICE"]);
requireAll(["RESEARCH_S3_BUCKET", "RESEARCH_S3_REGION"]);
if (!env.BETTER_AUTH_SECRET && (env.DINING_MODEL_URL || env.PRACTICE_API_BASE || env.RESEARCH_S3_BUCKET)) {
  errors.push("Learner model, conversation and research features require enabled accounts.");
}
for (const name of ["DINING_MODEL_URL", "PRACTICE_API_BASE", "RESEARCH_S3_ENDPOINT"]) {
  url(name, production ? ["https:"] : ["http:", "https:"]);
}
if (env.AUTH_DISABLE_SIGNUP && !["true", "false"].includes(env.AUTH_DISABLE_SIGNUP)) {
  errors.push("AUTH_DISABLE_SIGNUP must be true or false.");
}

if (databaseUrl && !errors.length) {
  const database = new pg.Client({ connectionString: env.DATABASE_URL, connectionTimeoutMillis: 5000, query_timeout: 5000 });
  try {
    await database.connect();
    const { rows } = await database.query("SELECT filename, checksum FROM app_schema_migrations");
    const applied = new Map(rows.map((row) => [row.filename, row.checksum]));
    const folder = new URL("../db/migrations/", import.meta.url);
    const migrations = (await readdir(folder)).filter((name) => /^\d+_.+\.sql$/.test(name));
    for (const filename of migrations) {
      const expected = createHash("sha256").update(await readFile(new URL(filename, folder))).digest("hex");
      if (applied.get(filename) !== expected) errors.push(`Migration missing or changed: ${filename}.`);
    }
  } catch {
    errors.push("Could not verify PostgreSQL and its migration ledger.");
  } finally {
    await database.end();
  }
}

if (errors.length) {
  errors.forEach((error) => console.error(error));
  process.exitCode = 1;
} else {
  console.log(databaseUrl ? "Deployment configuration and migration ledger checked." : "Guest deployment configuration checked.");
  if (production && env.BETTER_AUTH_SECRET && env.AUTH_DISABLE_SIGNUP !== "true") {
    console.log("This configuration permits public signup.");
  }
}
