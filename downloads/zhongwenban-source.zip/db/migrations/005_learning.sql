CREATE TABLE user_vocabulary (
  user_id text NOT NULL REFERENCES learner_profiles(user_id) ON DELETE CASCADE,
  word_key text NOT NULL,
  snapshot jsonb NOT NULL,
  saved_at timestamptz NOT NULL DEFAULT now(),
  due_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, word_key)
);

CREATE TABLE review_attempts (
  id uuid NOT NULL,
  user_id text NOT NULL,
  word_key text NOT NULL,
  remembered boolean NOT NULL,
  PRIMARY KEY (user_id, id),
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (user_id, word_key) REFERENCES user_vocabulary(user_id, word_key) ON DELETE CASCADE
);

CREATE TABLE lesson_completions (
  user_id text NOT NULL REFERENCES learner_profiles(user_id) ON DELETE CASCADE,
  id uuid NOT NULL,
  topic_id text NOT NULL,
  hsk_level text NOT NULL CHECK (hsk_level IN ('1','2','3')),
  completed_steps smallint[] NOT NULL,
  completed_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, id)
);

-- Receipts contain neither the recording nor its unedited transcript.
CREATE TABLE practice_transcriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES practice_sessions(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX practice_transcriptions_session_idx ON practice_transcriptions (session_id, created_at);

ALTER TABLE practice_turns ADD COLUMN spoken boolean;
