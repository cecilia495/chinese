import Link from "next/link";
import type { ReactNode } from "react";
import { practiceCopy } from "@/lib/practice-i18n";
import type { Locale } from "@/lib/i18n";

export function PracticeAccess({ locale, account, configured, children }: { locale: Locale; account: boolean; configured: boolean; children?: ReactNode }) {
  const t = practiceCopy[locale];
  return (
    <div className="panel">
      {children}
      {configured && !account ? <Link className="button" href="/account">{t.signIn}</Link> : <p>{t.disabled}</p>}
    </div>
  );
}
