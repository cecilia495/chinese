import Image from "next/image";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getDiningLesson } from "@/lib/dining";
import { dictionaries } from "@/lib/i18n";
import { getViewer } from "@/lib/preferences";
import { practiceCopy } from "@/lib/practice-i18n";
import { practiceServices } from "@/lib/practice-provider";
import { PracticeAccess } from "../practice/access";
import { Conversation } from "../practice/conversation";

export default async function TopicPage() {
  const { preferences: { locale, level }, user, needsSetup, accountsEnabled } = await getViewer();
  if (needsSetup) redirect("/settings");
  const t = dictionaries[locale];
  const p = practiceCopy[locale];
  const lesson = getDiningLesson(level);
  const services = practiceServices();
  const card = lesson && (
    <div className="topic-card">
      <Image src="/images/dining/dining-scene.webp" alt="" width={380} height={214} />
      <div>
        <p className="status">HSK {level}</p>
        <h2>{p.topic}</h2>
        <p>{lesson.goal[locale]}</p>
      </div>
    </div>
  );

  return (
    <section className="subpage lesson practice">
      <Link className="back" href="/">{t.back}</Link>
      <h1>{t.modes.topics.title}</h1>
      {!lesson ? <div className="panel">{t.unavailable}</div>
        : user && services.model
          ? <Conversation key={level} level={level} kind="topic" viewerKey={user.id} locale={locale} voice={services} topic={card} />
          : <PracticeAccess locale={locale} account={Boolean(user)} configured={accountsEnabled && services.model}>{card}</PracticeAccess>}
    </section>
  );
}
