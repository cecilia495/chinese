import Link from "next/link";
import { redirect } from "next/navigation";
import { dictionaries } from "@/lib/i18n";
import { getViewer } from "@/lib/preferences";
import { practiceCopy } from "@/lib/practice-i18n";
import { practiceServices } from "@/lib/practice-provider";
import { PracticeAccess } from "../practice/access";
import { PartnerPresence } from "../practice/partner-presence";
import { Conversation } from "../practice/conversation";

export default async function TalkPage({ searchParams }: { searchParams: Promise<{ mode?: string }> }) {
  const { preferences: { locale, level }, user, needsSetup, accountsEnabled } = await getViewer();
  if (needsSetup) redirect("/settings");
  const kind = (await searchParams).mode === "call" ? "call" : "chat";
  const t = dictionaries[locale];
  const p = practiceCopy[locale];
  const services = practiceServices();
  return (
    <section className="subpage lesson practice talk-page">
      <Link className="back" href="/">{t.back}</Link>
      <h1>{t.modes.talk.title}</h1>
      <nav className="lesson-options" aria-label={t.modes.talk.title}>
        <Link className="lesson-secondary" aria-current={kind === "chat" ? "page" : undefined} href="/talk">{p.chat}</Link>
        <Link className="lesson-secondary" aria-current={kind === "call" ? "page" : undefined} href="/talk?mode=call">{p.call}</Link>
      </nav>
      {user && services.model
        ? <Conversation key={`${kind}-${level}`} level={level} kind={kind} viewerKey={user.id} locale={locale} voice={services} />
        : <PracticeAccess locale={locale} account={Boolean(user)} configured={accountsEnabled && services.model}>
            <PartnerPresence locale={locale} activity="unavailable" />
          </PracticeAccess>}
    </section>
  );
}
