import Link from "next/link";
import { redirect } from "next/navigation";
import { getDatabase } from "@/lib/db";
import { savedVocabulary } from "@/lib/learning-store";
import { getDiningLesson } from "@/lib/dining";
import { diningCopy } from "@/lib/dining-i18n";
import { dictionaries } from "@/lib/i18n";
import { getViewer } from "@/lib/preferences";
import { diningModelConfigured } from "@/lib/dining-model";
import { DiningCourse } from "./dining-course";

export default async function LearnPage() {
  const { preferences: { locale, level }, user, needsSetup } = await getViewer();
  if (needsSetup) redirect("/settings");

  const t = dictionaries[locale];
  const lesson = getDiningLesson(level);
  const database = getDatabase();
  const favorites = lesson && database && user ? (await savedVocabulary(database, user.id)).map(({ key }) => key) : [];

  return (
    <section className="subpage lesson">
      <Link className="back" href="/">{t.back}</Link>
      <p className="status">HSK {level} · {diningCopy[locale].route}</p>
      <h1>{lesson?.title[locale] ?? t.modes.learn.title}</h1>
      {lesson ? (
        <>
          <p>{lesson.goal[locale]}</p>
          <p className="status">{diningCopy[locale].outline}</p>
          <DiningCourse lesson={lesson} locale={locale} viewerKey={user?.id ?? "guest"} favorites={favorites} canSave={Boolean(user && database)} aiAvailable={Boolean(user && diningModelConfigured())} />
        </>
      ) : <div className="panel">{t.unavailable}</div>}
    </section>
  );
}
