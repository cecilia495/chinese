"use client";

import { createAuthClient } from "better-auth/react";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import type { dictionaries } from "@/lib/i18n";

const auth = createAuthClient();
type Labels = (typeof dictionaries)["en"]["account"];

export function AuthForm({ labels, destination = "/", allowRegistration = true }: { labels: Labels; destination?: "/" | "/teacher"; allowRegistration?: boolean }) {
  const router = useRouter();
  const [registering, setRegistering] = useState(false);
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setPending(true);
    const form = new FormData(event.currentTarget);
    const email = String(form.get("email") ?? "").trim();
    const password = String(form.get("password") ?? "");

    try {
      const result = registering
        ? await auth.signUp.email({ email, password, name: String(form.get("name") ?? "").trim() })
        : await auth.signIn.email({ email, password, rememberMe: true });
      if (result.error) {
        setError(result.error.status === 429 ? labels.rateLimit : registering ? labels.registrationError : labels.signInError);
      } else {
        router.replace(destination);
        router.refresh();
        return;
      }
    } catch {
      setError(labels.serviceError);
    }
    setPending(false);
  }

  return (
    <form className="panel preferences" method="post" onSubmit={submit}>
      {registering && (
        <>
          <label htmlFor="name">{labels.name}</label>
          <input id="name" name="name" autoComplete="name" maxLength={100} required />
        </>
      )}
      <label htmlFor="email">{labels.email}</label>
      <input id="email" name="email" type="email" autoComplete="email" maxLength={254} required />
      <label htmlFor="password">{labels.password}</label>
      <input id="password" name="password" type="password" autoComplete={registering ? "new-password" : "current-password"}
        minLength={registering ? 12 : undefined} maxLength={128} required aria-describedby={registering ? "password-help" : undefined} />
      {registering && <p id="password-help">{labels.passwordHelp}</p>}
      {error && <p className="form-error" role="alert">{error}</p>}
      <button className="button" type="submit" disabled={pending}>
        {pending ? labels.pending : registering ? labels.register : labels.signIn}
      </button>
      {allowRegistration && <button className="text-button" type="button" disabled={pending} onClick={() => {
        setRegistering(!registering);
        setError("");
      }}>
        {registering ? labels.signIn : labels.register}
      </button>}
    </form>
  );
}

export function SignOut({ labels }: { labels: Labels }) {
  const router = useRouter();
  const [error, setError] = useState(false);
  const [pending, setPending] = useState(false);

  async function signOut() {
    setPending(true);
    setError(false);
    try {
      const result = await auth.signOut();
      if (!result.error) {
        router.replace("/");
        router.refresh();
        return;
      }
    } catch {
      // The same localized error also covers network failures.
    }
    setPending(false);
    setError(true);
  }

  return (
    <>
      <button className="button" type="button" onClick={signOut} disabled={pending}>{pending ? labels.pending : labels.signOut}</button>
      {error && <p className="form-error" role="alert">{labels.serviceError}</p>}
    </>
  );
}
