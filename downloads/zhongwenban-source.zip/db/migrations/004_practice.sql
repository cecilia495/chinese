CREATE TABLE practice_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL REFERENCES learner_profiles(user_id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('topic', 'chat', 'call')),
  topic_id text,
  hsk_level text NOT NULL,
  interface_language text NOT NULL,
  config_version integer NOT NULL DEFAULT 1,
  feedback_mode text NOT NULL CHECK (feedback_mode IN ('natural', 'gentle', 'key', 'detailed')),
  opening text NOT NULL,
  summary text,
  revision integer NOT NULL DEFAULT 0,
  started_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz
);
CREATE INDEX practice_sessions_user_idx ON practice_sessions (user_id, started_at DESC);

CREATE TABLE practice_turns (
  session_id uuid NOT NULL REFERENCES practice_sessions(id) ON DELETE CASCADE,
  position integer NOT NULL,
  learner_text text NOT NULL,
  assistant_text text NOT NULL,
  translation text NOT NULL,
  hint text NOT NULL,
  feedback text NOT NULL,
  feedback_mode text NOT NULL CHECK (feedback_mode IN ('natural', 'gentle', 'key', 'detailed')),
  interface_language text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (session_id, position)
);

CREATE TABLE practice_mode_events (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  session_id uuid NOT NULL REFERENCES practice_sessions(id) ON DELETE CASCADE,
  previous_mode text NOT NULL,
  next_mode text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX practice_mode_events_session_idx ON practice_mode_events (session_id, id);

CREATE TABLE practice_request_quota (
  user_id text NOT NULL REFERENCES learner_profiles(user_id) ON DELETE CASCADE,
  service text NOT NULL CHECK (service IN ('model', 'asr', 'tts')),
  window_start timestamptz NOT NULL DEFAULT now(),
  requests integer NOT NULL DEFAULT 1,
  PRIMARY KEY (user_id, service)
);

ALTER TABLE learner_profiles ALTER COLUMN speech_rate DROP NOT NULL;
ALTER TABLE learner_profiles ALTER COLUMN speech_rate DROP DEFAULT;
-- Earlier releases always initialized this value to 1.00 and offered no rate selector.
UPDATE learner_profiles SET speech_rate = NULL WHERE speech_rate = 1.00;

ALTER TABLE practice_sessions ADD COLUMN voice_id text;
ALTER TABLE practice_sessions ADD COLUMN speech_rate numeric(3,2);
