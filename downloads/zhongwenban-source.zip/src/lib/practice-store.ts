import type { Pool, PoolClient } from "pg";
import type { FeedbackMode, PracticeSession, PracticeTurn } from "./practice";

export async function loadPractice(database: Pool, userId: string, id: string): Promise<PracticeSession | undefined> {
  const { rows } = await database.query<PracticeSession>(
    `SELECT s.id, s.kind, s.hsk_level AS level, s.feedback_mode AS mode, s.opening,
            s.voice_id AS voice, s.speech_rate::double precision AS "speechRate",
            s.summary, s.ended_at IS NOT NULL AS ended, s.revision,
            COALESCE((SELECT jsonb_agg(jsonb_build_object(
                'position', t.position, 'learner', t.learner_text, 'reply', t.assistant_text,
                'translation', t.translation, 'hint', t.hint, 'feedback', t.feedback,
                'mode', t.feedback_mode) ORDER BY t.position)
              FROM practice_turns t WHERE t.session_id = s.id), '[]'::jsonb) AS turns
       FROM practice_sessions s WHERE s.user_id = $1 AND s.id = $2`,
    [userId, id],
  );
  return rows[0];
}

export async function consumeQuota(database: Pool, userId: string, service: "model" | "asr" | "tts") {
  const maximum = service === "tts" ? 30 : 16;
  const { rowCount } = await database.query(
    `INSERT INTO practice_request_quota (user_id, service) VALUES ($1, $2)
     ON CONFLICT (user_id, service) DO UPDATE
     SET requests = CASE WHEN practice_request_quota.window_start <= now() - interval '5 minutes'
                         THEN 1 ELSE practice_request_quota.requests + 1 END,
         window_start = CASE WHEN practice_request_quota.window_start <= now() - interval '5 minutes'
                             THEN now() ELSE practice_request_quota.window_start END
     WHERE practice_request_quota.requests < $3 OR practice_request_quota.window_start <= now() - interval '5 minutes'
     RETURNING requests`,
    [userId, service, maximum],
  );
  return Boolean(rowCount);
}

export async function savePracticeChange(
  database: Pool, userId: string, session: PracticeSession, change: (client: PoolClient) => Promise<unknown>,
) {
  const client = await database.connect();
  try {
    await client.query("BEGIN");
    const { rowCount } = await client.query(
      `UPDATE practice_sessions SET revision = revision + 1
       WHERE id = $1 AND user_id = $2 AND revision = $3 AND ended_at IS NULL`,
      [session.id, userId, session.revision],
    );
    if (!rowCount) {
      await client.query("ROLLBACK");
      return false;
    }
    await change(client);
    await client.query("COMMIT");
    return true;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function storeTurn(client: PoolClient, id: string, turn: PracticeTurn, locale: string, transcriptionId: string | null, revisionOf: number | null) {
  const receipt = transcriptionId && await client.query(
    `DELETE FROM practice_transcriptions WHERE session_id = $1 AND id = $2
     AND created_at > now() - interval '1 hour' RETURNING id`, [id, transcriptionId],
  );
  await client.query(
    `INSERT INTO practice_turns
       (session_id, position, learner_text, assistant_text, translation, hint, feedback, feedback_mode, interface_language, spoken, revision_of)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
    [id, turn.position, turn.learner, turn.reply, turn.translation, turn.hint, turn.feedback, turn.mode, locale, Boolean(receipt && receipt.rowCount), revisionOf],
  );
  if (receipt && receipt.rowCount) {
    await client.query(
      `UPDATE research_recordings r SET turn_position = $3
       FROM research_consents c
       WHERE r.consent_id = c.id AND c.revoked_at IS NULL
         AND r.session_id = $1 AND r.id = $2 AND r.stored AND r.turn_position IS NULL`,
      [id, transcriptionId, turn.position],
    );
  }
}

export async function storeMode(client: PoolClient, session: PracticeSession, mode: FeedbackMode) {
  await client.query("UPDATE practice_sessions SET feedback_mode = $2 WHERE id = $1", [session.id, mode]);
  await client.query(
    "INSERT INTO practice_mode_events (session_id, previous_mode, next_mode) VALUES ($1,$2,$3)",
    [session.id, session.mode, mode],
  );
}
