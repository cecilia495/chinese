import { getDatabase } from "@/lib/db";

export const runtime = "nodejs";

export async function GET() {
  try {
    const database = getDatabase();
    if (!database) return Response.json({ app: "ok", database: "not_configured" });

    await database.query("SELECT 1");
    return Response.json({ app: "ok", database: "ok" });
  } catch {
    return Response.json({ app: "ok", database: "unavailable" }, { status: 503 });
  }
}
