import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { once } from "node:events";
import { createReadStream, createWriteStream } from "node:fs";
import { mkdir, readFile, stat, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { pipeline } from "node:stream/promises";
import {
  GetObjectCommand, ListObjectsV2Command, PutObjectCommand, S3Client,
} from "@aws-sdk/client-s3";
import pg from "pg";
import { loadOperationsEnv } from "./operations-env.mjs";

const maxRecordingBytes = 4 * 1024 * 1024;
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const mimeTypes = new Set(["audio/webm", "audio/ogg", "audio/mp4", "audio/wav"]);
const env = process.env;

function databaseConnection(connectionString) {
  return new pg.Client({ connectionString, connectionTimeoutMillis: 5000 });
}

function runPostgres(tool, connectionString, options, stream) {
  const url = new URL(connectionString);
  const password = url.searchParams.get("password") || decodeURIComponent(url.password);
  url.searchParams.delete("password");
  url.password = "";
  const child = spawn(tool, [`--dbname=${url.href}`, ...options], {
    env: password ? { ...env, PGPASSWORD: password } : env,
    stdio: tool === "pg_dump" ? ["ignore", "pipe", "ignore"] : ["pipe", "ignore", "ignore"],
  });
  const copy = tool === "pg_dump" ? pipeline(child.stdout, stream) : pipeline(stream, child.stdin);
  const exit = once(child, "close").then(([code]) => {
    if (code !== 0) throw new Error(`${tool} exited unsuccessfully.`);
  });
  return Promise.all([copy, exit]);
}

function objectStorage(restore = false) {
  const prefix = restore ? "RESTORE_RESEARCH_S3_" : "RESEARCH_S3_";
  const bucket = env[prefix + "BUCKET"];
  const region = env[prefix + "REGION"];
  if (!bucket || !region) throw new Error(`Set ${prefix}BUCKET and ${prefix}REGION to handle audio.`);
  const client = new S3Client({
    region, endpoint: env[prefix + "ENDPOINT"] || undefined,
    forcePathStyle: env[prefix + "PATH_STYLE"] === "true", maxAttempts: 2,
  });
  return { client, bucket };
}

function storageRequest(storage, command) {
  return storage.client.send(command, { abortSignal: AbortSignal.timeout(20_000) });
}

async function expectedRecordings(database) {
  const { rows } = await database.query(
    `SELECT r.recording_id, r.object_key, r.mime_type, r.size_bytes, r.sha256
       FROM research_recordings r JOIN research_consents c ON c.id = r.consent_id
      WHERE r.stored AND r.turn_position IS NOT NULL AND c.revoked_at IS NULL
      ORDER BY r.recording_id`,
  );
  return rows;
}

function validRecording(row) {
  if (!row || !uuid.test(row.recording_id) || typeof row.object_key !== "string") return false;
  const [prefix, session, capture, extra] = row.object_key.split("/");
  return !extra && prefix === "research" && uuid.test(session) && uuid.test(capture) &&
    mimeTypes.has(row.mime_type) && Number.isInteger(row.size_bytes) &&
    row.size_bytes > 0 && row.size_bytes <= maxRecordingBytes && /^[0-9a-f]{64}$/.test(row.sha256);
}

function checkBytes(bytes, row) {
  if (bytes.length !== row.size_bytes || createHash("sha256").update(bytes).digest("hex") !== row.sha256) {
    throw new Error("A recording failed its length or SHA-256 check.");
  }
}

async function hashFile(file) {
  const hash = createHash("sha256");
  for await (const bytes of createReadStream(file)) hash.update(bytes);
  return hash.digest("hex");
}

async function backup(directory) {
  if (!env.DATABASE_URL) throw new Error("Set DATABASE_URL.");
  const dump = join(directory, "database.dump");
  try {
    await mkdir(directory, { mode: 0o700 });
  } catch (error) {
    if (error.code === "EEXIST") throw new Error("Backup directory already exists.");
    throw error;
  }
  const database = databaseConnection(env.DATABASE_URL);
  let storage;
  try {
    await database.connect();
    await database.query("BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY");
    const { rows: [state] } = await database.query("SELECT pg_export_snapshot() AS snapshot");
    const recordings = await expectedRecordings(database);
    if (!recordings.every(validRecording)) throw new Error("Invalid recording catalog.");
    await runPostgres("pg_dump", env.DATABASE_URL, [
      "--format=custom", "--no-owner", "--no-privileges", `--snapshot=${state.snapshot}`,
    ], createWriteStream(dump, { flags: "wx", mode: 0o600 }));
    await database.query("COMMIT");

    if (recordings.length) {
      storage = objectStorage();
      await mkdir(join(directory, "audio"), { mode: 0o700 });
    }
    for (const row of recordings) {
      const object = await storageRequest(storage, new GetObjectCommand({ Bucket: storage.bucket, Key: row.object_key }));
      if (!object.Body || object.ContentLength !== row.size_bytes) throw new Error("Unexpected recording size in object storage.");
      const bytes = await object.Body.transformToByteArray();
      checkBytes(bytes, row);
      await writeFile(join(directory, "audio", row.recording_id + ".bin"), bytes, { flag: "wx", mode: 0o600 });
    }
    const manifest = { version: 1, createdAt: new Date().toISOString(), databaseSha256: await hashFile(dump), recordings };
    await writeFile(join(directory, "manifest.json"), JSON.stringify(manifest, null, 2) + "\n", { flag: "wx", mode: 0o600 });
    console.log(`Backup complete. Verified original recordings: ${recordings.length}.`);
  } finally {
    storage?.client.destroy();
    await database.end();
  }
}

function sameDatabase(a, b) {
  const normalized = (value) => {
    const url = new URL(value);
    return [url.hostname, url.port || "5432", decodeURIComponent(url.pathname)].join("|");
  };
  return normalized(a) === normalized(b);
}

function sameRecordings(actual, expected) {
  return actual.length === expected.length && actual.every((row, index) =>
    ["recording_id", "object_key", "mime_type", "size_bytes", "sha256"].every((key) => row[key] === expected[index][key]));
}

async function readAudioFile(directory, row) {
  const file = join(directory, "audio", row.recording_id + ".bin");
  if ((await stat(file)).size !== row.size_bytes) throw new Error("A recording file has an unexpected size.");
  const bytes = await readFile(file);
  checkBytes(bytes, row);
  return bytes;
}

async function restore(directory) {
  const target = env.RESTORE_DATABASE_URL;
  if (!target) throw new Error("Set RESTORE_DATABASE_URL to an empty isolated database.");
  if (env.DATABASE_URL && sameDatabase(target, env.DATABASE_URL)) throw new Error("The database target matches DATABASE_URL.");
  const manifest = JSON.parse(await readFile(join(directory, "manifest.json"), "utf8"));
  const dump = join(directory, "database.dump");
  if (manifest.version !== 1 || !Array.isArray(manifest.recordings) || !manifest.recordings.every(validRecording) ||
      manifest.databaseSha256 !== await hashFile(dump)) throw new Error("Backup manifest or database checksum is invalid.");

  for (const row of manifest.recordings) await readAudioFile(directory, row);

  const database = databaseConnection(target);
  let storage;
  try {
    await database.connect();
    const inventory = await database.query(
      `SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
       WHERE n.nspname !~ '^pg_' AND n.nspname <> 'information_schema'
       AND c.relkind IN ('r','v','m','p','S','f') LIMIT 1`,
    );
    if (inventory.rowCount) throw new Error("Restore requires an empty target database.");
    if (manifest.recordings.length) {
      storage = objectStorage(true);
      if (storage.bucket === env.RESEARCH_S3_BUCKET) throw new Error("The recording target matches RESEARCH_S3_BUCKET.");
      const listing = await storageRequest(storage, new ListObjectsV2Command({ Bucket: storage.bucket, MaxKeys: 1 }));
      if (listing.Contents?.length || listing.IsTruncated) throw new Error("Restore requires an empty target bucket.");
    }

    await runPostgres("pg_restore", target, ["--format=custom", "--no-owner", "--no-privileges", "--single-transaction", "--exit-on-error"], createReadStream(dump));
    const recordings = await expectedRecordings(database);
    if (!sameRecordings(recordings, manifest.recordings)) throw new Error("Restored database does not match the recording catalog.");
    for (const row of recordings) {
      const bytes = await readAudioFile(directory, row);
      await storageRequest(storage, new PutObjectCommand({
        Bucket: storage.bucket, Key: row.object_key, Body: bytes, ContentType: row.mime_type, IfNoneMatch: "*",
      }));
      const confirmed = await storageRequest(storage, new GetObjectCommand({ Bucket: storage.bucket, Key: row.object_key }));
      if (!confirmed.Body || confirmed.ContentLength !== row.size_bytes) throw new Error("Restored recording could not be verified.");
      checkBytes(await confirmed.Body.transformToByteArray(), row);
    }

    await database.query(`BEGIN;
      DELETE FROM research_recordings r USING research_consents c
      WHERE r.consent_id = c.id AND (c.revoked_at IS NOT NULL OR r.turn_position IS NULL OR NOT r.stored);
      DELETE FROM practice_transcriptions;
      DELETE FROM "session";
      COMMIT;`);
    console.log(`Restore verified. Original recordings: ${recordings.length}. Accounts must sign in again.`);
  } finally {
    storage?.client.destroy();
    await database.end();
  }
}

loadOperationsEnv();
const [action, folder] = process.argv.slice(2);
try {
  if (!folder || !["backup", "restore"].includes(action)) {
    throw new Error("Usage: node scripts/backup-restore.mjs backup|restore <directory>");
  }
  await (action === "backup" ? backup : restore)(resolve(folder));
} catch (error) {
  const safe = typeof error.message === "string" && /^(Set |Backup |Restore |The |Invalid |Unexpected |A recording |Restored |Usage:|pg_(dump|restore) )/.test(error.message);
  console.error(safe ? error.message : "Operation failed. The destination may be incomplete. Check configuration before retrying with a new destination.");
  process.exitCode = 1;
}
